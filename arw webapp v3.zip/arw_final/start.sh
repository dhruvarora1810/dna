#!/bin/bash
# ═══════════════════════════════════════════════
#  start.sh  —  Launch ARW Feature Builder
# ═══════════════════════════════════════════════
cd "$(dirname "$0")"

# check dependencies
python3 -c "import flask" 2>/dev/null   || { echo "❌  flask not found.   Install: pip install flask"; exit 1; }
python3 -c "import trino" 2>/dev/null   || { echo "❌  trino not found.   Install: pip install trino"; exit 1; }
python3 -c "import pandas" 2>/dev/null  || { echo "❌  pandas not found.  Install: pip install pandas"; exit 1; }

echo ""
echo "  🛡️  ARW Feature Builder"
echo "  Form previews → Starburst (fast)"
echo "  Code editor   → Spark (lazy init)"
echo ""
echo "  Access: http://$(hostname -f):8050"
echo "  Ctrl+C to stop."
echo ""

python3 app.py
