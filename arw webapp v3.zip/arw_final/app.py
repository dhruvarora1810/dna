from __future__ import annotations
"""
app.py  —  ARW Feature Builder  (semantic-model edition)
========================================================
Form Builder → Starburst/Trino. Analyst picks Table → Entity (grain) → Aggregation
→ Field, all by friendly name. The semantic model maps friendly names to real
columns and auto-casts string columns (e.g. amount stored as text).

Code Editor → Spark (runs only when deployed on the cluster / OpenShift).

Start:  set TRINO_PASSWORD=...   then   python app.py
"""
import json, sqlite3, threading, traceback, uuid, textwrap
from datetime import datetime, timezone, date, timedelta
from pathlib import Path

from flask import Flask, jsonify, render_template, request

import config

app = Flask(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
#  STARBURST / TRINO
# ═══════════════════════════════════════════════════════════════════════════════
import trino
import trino.auth
import pandas as pd
import urllib3
urllib3.disable_warnings()


def _trino_conn() -> "trino.dbapi.Connection":
    auth = None
    if config.STARBURST_AUTH == "basic":
        auth = trino.auth.BasicAuthentication(config.STARBURST_USER, config.STARBURST_PASSWORD)
    elif config.STARBURST_AUTH == "kerberos":
        auth = trino.auth.KerberosAuthentication()
    return trino.dbapi.connect(
        host         = config.STARBURST_HOST,
        port         = config.STARBURST_PORT,
        user         = config.STARBURST_USER,
        http_scheme  = getattr(config, "STARBURST_HTTP_SCHEME", "https"),
        auth         = auth,
        catalog      = config.STARBURST_CATALOG,
        schema       = config.STARBURST_SCHEMA,
        verify       = getattr(config, "STARBURST_VERIFY_SSL", False),
        session_properties = getattr(config, "STARBURST_SESSION_PROPS", {}),
    )


# ── semantic-model lookups ─────────────────────────────────────────────────────
def _table_meta(table: str) -> dict:
    for t in config.TABLES:
        if t["table"] == table:
            return t
    raise ValueError(f"Table '{table}' is not in the semantic model")


def _entity_columns(meta: dict) -> list:
    return [e["column"] for e in meta["entities"]]


def _field_meta(meta: dict, column: str) -> dict:
    for f in meta["fields"]:
        if f["column"] == column:
            return f
    raise ValueError(f"Field '{column}' is not declared for table '{meta['table']}'")


def _field_expr(meta: dict, column: str) -> str:
    """Return the SQL expression for a field, applying CAST per its declared type."""
    f = _field_meta(meta, column)
    if f["type"] == "string_double":
        return f"CAST({column} AS DOUBLE)"
    return column   # numeric / string → use as-is


def _window_bounds(n_days: int) -> tuple:
    end_d   = date.today()
    start_d = end_d - timedelta(days=n_days)
    return start_d.strftime("%Y%m%d"), end_d.strftime("%Y%m%d")


def _latest_partition(table: str, partition_col: str) -> str:
    try:
        recent = (date.today() - timedelta(days=7)).strftime("%Y%m%d")
        sql  = f"SELECT MAX({partition_col}) FROM {table} WHERE {partition_col} >= '{recent}'"
        conn = _trino_conn(); cur = conn.cursor(); cur.execute(sql)
        row = cur.fetchone()
        return str(row[0]) if row and row[0] is not None else date.today().strftime("%Y%m%d")
    except Exception:
        return date.today().strftime("%Y%m%d")


def _run_form_job(spec: dict) -> dict:
    meta          = _table_meta(spec["source_table"])
    table         = meta["table"]
    partition_col = meta["partition_col"]
    entity_col    = spec["entity_col"]
    n     = int(spec["window_days"])
    name  = spec["name"]
    filt  = (spec.get("filter_expr") or "").strip()
    agg   = spec["aggregation"]
    field = (spec.get("agg_field") or "").strip() or None

    if entity_col not in _entity_columns(meta):
        raise ValueError(f"Entity '{entity_col}' is not valid for this table")

    # field expression with type-aware casting
    if agg in ("sum", "avg", "min", "max", "count_distinct"):
        if not field:
            raise ValueError(f"'{agg}' requires a field")
        expr = _field_expr(meta, field)
    else:
        expr = None

    agg_sql = {
        "count":          "COUNT(*)",
        "sum":            f"SUM({expr})",
        "avg":            f"AVG({expr})",
        "min":            f"MIN({expr})",
        "max":            f"MAX({expr})",
        "count_distinct": f"COUNT(DISTINCT {expr})",
    }.get(agg)
    if agg_sql is None:
        raise ValueError(f"Unknown aggregation: {agg}")

    start_s, end_s = _window_bounds(n)
    where = [f"{partition_col} >= '{start_s}'"]
    if filt:
        where.append(f"({filt})")
    where_sql = "\n      AND ".join(where)

    sql = textwrap.dedent(f"""
        SELECT {entity_col},
               {agg_sql} AS {name}
        FROM   {table}
        WHERE  {where_sql}
        GROUP BY {entity_col}
        ORDER BY {name} DESC
        LIMIT  {config.PREVIEW_LIMIT}
    """).strip()

    conn = _trino_conn(); cur = conn.cursor(); cur.execute(sql)
    rows = cur.fetchall(); cols = [d[0] for d in cur.description]
    pdf  = pd.DataFrame(rows, columns=cols)
    return {"columns": list(pdf.columns), "rows": pdf.values.tolist(),
            "latest": end_s, "n_parts": f"{start_s}–{end_s}", "count": len(pdf),
            "sql": sql, "engine": "starburst"}


# ═══════════════════════════════════════════════════════════════════════════════
#  SPARK  (code editor — cluster/OpenShift only)
# ═══════════════════════════════════════════════════════════════════════════════
_spark = None
_spark_lock = threading.Lock()


def _get_spark():
    global _spark
    if _spark is None:
        with _spark_lock:
            if _spark is None:
                from pyspark.sql import SparkSession
                _spark = (SparkSession.builder
                          .appName(config.SPARK_APP_NAME)
                          .config("spark.executor.memory", config.SPARK_EXECUTOR_MEM)
                          .config("spark.driver.memory",   config.SPARK_DRIVER_MEM)
                          .config("spark.sql.catalogImplementation", "hive")
                          .enableHiveSupport()
                          .getOrCreate())
    return _spark


def _run_code_job(code_str: str, table: str, n_days: int) -> dict:
    import pyspark.sql.functions as F  # noqa
    meta = _table_meta(table)
    start_s, _ = _window_bounds(n_days)
    df = _get_spark().sql(
        f"SELECT * FROM {meta['table']} WHERE {meta['partition_col']} >= '{start_s}'"
    )
    # default entity = first declared
    entity_col = meta["entities"][0]["column"]
    ns = {}
    exec(compile(code_str, "<feature_editor>", "exec"), ns)
    if "compute_feature" not in ns:
        raise ValueError("Code must define:  def compute_feature(df, entity_col)")
    result = ns["compute_feature"](df, entity_col).limit(config.PREVIEW_LIMIT)
    pdf    = result.toPandas()
    return {"columns": list(pdf.columns), "rows": pdf.values.tolist(),
            "latest": start_s, "n_parts": n_days, "count": len(pdf),
            "sql": None, "engine": "spark"}


# ═══════════════════════════════════════════════════════════════════════════════
#  REGISTRY
# ═══════════════════════════════════════════════════════════════════════════════
def _reg():
    Path(config.REGISTRY_DB).parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(config.REGISTRY_DB)
    con.row_factory = sqlite3.Row
    con.executescript("""
        CREATE TABLE IF NOT EXISTS feature (
            name TEXT PRIMARY KEY, source_table TEXT, entity_col TEXT, mode TEXT,
            spec_json TEXT, code_body TEXT, owner TEXT,
            status TEXT DEFAULT 'pending', submitted_at TEXT
        );
        CREATE TABLE IF NOT EXISTS audit (
            id INTEGER PRIMARY KEY AUTOINCREMENT, feature_name TEXT,
            action TEXT, actor TEXT, note TEXT, ts TEXT
        );
    """)
    con.commit()
    return con


def _ts() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


_jobs: dict = {}


def _run_in_thread(job_id: str, fn, *args):
    def _worker():
        try:
            _jobs[job_id] = {"status": "done", "result": fn(*args)}
        except Exception as e:
            _jobs[job_id] = {"status": "error", "error": traceback.format_exc(limit=8),
                             "message": str(e)}
    _jobs[job_id] = {"status": "running"}
    threading.Thread(target=_worker, daemon=True).start()


# ═══════════════════════════════════════════════════════════════════════════════
#  ROUTES
# ═══════════════════════════════════════════════════════════════════════════════
def _tables_payload() -> list:
    return [{
        "label": t["label"], "table": t["table"], "partition": t["partition_col"],
        "entities": t["entities"], "fields": t["fields"],
    } for t in config.TABLES]


@app.route("/")
def index():
    return render_template("index.html", tables=json.dumps(_tables_payload()))


@app.route("/api/tables")
def api_tables():
    return jsonify(_tables_payload())


@app.route("/api/info")
def api_info():
    table = request.args.get("table", "")
    try:
        meta = _table_meta(table)
        latest = _latest_partition(meta["table"], meta["partition_col"])
        return jsonify({"latest": latest, "partition_col": meta["partition_col"],
                        "entities": meta["entities"], "fields": meta["fields"],
                        "table": meta["table"]})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/run/form", methods=["POST"])
def api_run_form():
    spec = request.json
    for k in ["name", "aggregation", "window_days", "owner", "source_table", "entity_col"]:
        if not spec.get(k):
            return jsonify({"error": f"'{k}' is required"}), 400
    if " " in spec["name"]:
        return jsonify({"error": "Feature name must have no spaces"}), 400
    job_id = str(uuid.uuid4())[:8]
    _run_in_thread(job_id, _run_form_job, spec)
    return jsonify({"job_id": job_id})


@app.route("/api/run/code", methods=["POST"])
def api_run_code():
    body  = request.json
    name  = (body.get("name") or "").strip()
    owner = (body.get("owner") or "").strip()
    table = (body.get("source_table") or "").strip()
    code  = body.get("code", "")
    n     = int(body.get("window_days", 30))
    if not name or " " in name:
        return jsonify({"error": "Feature name must be non-empty with no spaces"}), 400
    if not owner:
        return jsonify({"error": "Owner is required"}), 400
    if "compute_feature" not in code:
        return jsonify({"error": "Code must define:  def compute_feature(df, entity_col)"}), 400
    job_id = str(uuid.uuid4())[:8]
    _run_in_thread(job_id, _run_code_job, code, table, n)
    return jsonify({"job_id": job_id})


@app.route("/api/job/<job_id>")
def api_job_status(job_id):
    job = _jobs.get(job_id)
    if not job:
        return jsonify({"status": "unknown"}), 404
    return jsonify(job)


@app.route("/api/submit", methods=["POST"])
def api_submit():
    body  = request.json
    name  = (body.get("name") or "").strip()
    owner = (body.get("owner") or "").strip()
    table = body.get("source_table", "")
    entity= body.get("entity_col", "")
    mode  = body.get("mode", "form")
    if not name or not owner:
        return jsonify({"error": "name and owner are required"}), 400
    con = _reg(); ts = _ts()
    con.execute("""
        INSERT INTO feature (name,source_table,entity_col,mode,spec_json,code_body,owner,status,submitted_at)
        VALUES (?,?,?,?,?,?,?,'pending',?)
        ON CONFLICT(name) DO UPDATE SET
            source_table=excluded.source_table, entity_col=excluded.entity_col,
            mode=excluded.mode, spec_json=excluded.spec_json, code_body=excluded.code_body,
            owner=excluded.owner, status='pending', submitted_at=excluded.submitted_at
    """, (name, table, entity, mode,
          json.dumps(body.get("spec")) if body.get("spec") else None,
          body.get("code"), owner, ts))
    con.execute("INSERT INTO audit (feature_name,action,actor,note,ts) VALUES (?,?,?,?,?)",
                (name, "submit", owner, f"mode={mode} table={table} entity={entity}", ts))
    con.commit(); con.close()
    return jsonify({"ok": True, "name": name, "status": "pending", "submitted_at": ts})


@app.route("/api/queue")
def api_queue():
    con  = _reg()
    rows = con.execute(
        "SELECT name,source_table,entity_col,mode,owner,status,submitted_at FROM feature ORDER BY submitted_at DESC"
    ).fetchall()
    con.close()
    return jsonify([dict(r) for r in rows])


if __name__ == "__main__":
    if config.STARBURST_AUTH == "basic" and not config.STARBURST_PASSWORD:
        print("⚠️   No password set. Run:  set TRINO_PASSWORD=yourpassword   then restart.")
    print(f"\n🛡️  ARW Feature Builder (semantic model)")
    print(f"   Starburst : {config.STARBURST_HOST}:{config.STARBURST_PORT}")
    print(f"   Tables    : {[t['table'] for t in config.TABLES]}")
    print(f"   Access    : http://localhost:{config.PORT}\n")
    app.run(host=config.HOST, port=config.PORT, threaded=True)
