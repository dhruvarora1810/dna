# ═══════════════════════════════════════════════════════════════════════
#  config.py  —  Semantic model + connection settings
#  Edit values marked  ← CHANGE THIS
# ═══════════════════════════════════════════════════════════════════════
import os

# ── SEMANTIC MODEL ───────────────────────────────────────────────────────
# For each table, declare:
#   entities : the grains an analyst can group by (friendly label → real column)
#   fields   : aggregatable columns, with a TYPE so the query builder knows
#              whether to CAST. type options:
#                "numeric"        → use as-is
#                "string_double"  → wrap CAST(col AS DOUBLE)   (e.g. amount stored as text)
#                "string"         → use as-is (for count_distinct / filters)
#   entity "windowed": True  → supports trailing-window aggregation (account/card)
#                      False → row-level grain, window is meaningless (transaction)
TABLES = [
    {
        "label": "FCM_CCCA — Branded Cards Auth",
        "table": "fcm_ccca_vw",
        "partition_col": "load_date",
        "entities": [
            {"label": "Account",     "column": "aqo_acct_num", "windowed": True},
            {"label": "Card",        "column": "hqo_card_num",  "windowed": True},
            {"label": "Transaction", "column": "cmx_tran_id",   "windowed": False},
        ],
        "fields": [
            {"label": "Amount",        "column": "tca_client_amt",  "type": "string_double"},
            {"label": "MCC",           "column": "hct_mer_mcc",     "type": "string"},
            {"label": "Decision code", "column": "rrr_action_code", "type": "string"},
        ],
    },
    # add more tables here, same shape
]

# ── Starburst / Trino ────────────────────────────────────────────────────
STARBURST_HOST        = "query.dataanalytics.citigroup.net"
STARBURST_PORT        = 8980
STARBURST_USER        = "da60046"                              # ← CHANGE THIS
STARBURST_CATALOG     = "pbwm_eap_sb"
STARBURST_SCHEMA      = "gcgcrsnaprp_sfmd_fr_all_v_c_pii_db"
STARBURST_HTTP_SCHEME = "https"
STARBURST_AUTH        = "basic"
STARBURST_PASSWORD    = os.environ.get("TRINO_PASSWORD", "")   # set:  set TRINO_PASSWORD=...
STARBURST_VERIFY_SSL  = False
STARBURST_SESSION_PROPS = {"query_max_execution_time": "5m"}

# ── Spark (code editor — used only when deployed on the cluster) ──────────
SPARK_APP_NAME      = "ARW-FeatureBuilder"
SPARK_EXECUTOR_MEM  = "4g"
SPARK_DRIVER_MEM    = "2g"

# ── App ───────────────────────────────────────────────────────────────────
REGISTRY_DB   = os.path.join(os.path.expanduser("~"), "arw_registry.db")
HOST          = "0.0.0.0"
PORT          = 8050
PREVIEW_LIMIT = 50
