class PipelineState:
    def __init__(self):
        self.steps = []

    def add_step(self, name):
        self.steps.append(name)

    def show(self):
        print("Pipeline Steps:", self.steps)
