from pyspark.sql import SparkSession
from .validators import validate_df

def run_pipeline(sql, feature_func, scoring_func, model=None):
    spark = SparkSession.builder.getOrCreate()

    print("🚀 Running SQL...")
    df = spark.sql(sql)

    print("⚙️ Running Feature Engineering...")
    df = feature_func(df)

    validate_df(df)

    if model:
        print("📦 Broadcasting model...")
        bc_model = spark.sparkContext.broadcast(model)

        def wrapped_score(df):
            return scoring_func(df, bc_model.value)

        print("🤖 Running Scoring...")
        df = wrapped_score(df)

    print("✅ Pipeline Completed")
    return df
