def validate_df(df):
    import inspect

    source = inspect.getsource(df.__class__)

    blocked_patterns = [
        "toPandas",
        "collect(",
        "rdd",
    ]

    for pattern in blocked_patterns:
        if pattern in source:
            raise Exception(f"❌ Guardrail Violation: {pattern} is not allowed")

    print("✅ Guardrails Passed")
