import argparse

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sql", required=True)
    parser.add_argument("--model", required=False)
    return parser.parse_args()
