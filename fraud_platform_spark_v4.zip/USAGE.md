# Fraud Platform Spark v4 - Usage Guide

## What the user provides

The user provides exactly three things:

1. **SQL query** for input data
2. **Feature engineering Python code**
3. **Model scoring Python code**

The framework handles:
- Spark SQL execution
- distributed execution on Spark/YARN
- model broadcast from pickle
- output as a Spark DataFrame

## Example 1 - Feature engineering file

```python
from fraud_platform_spark import feature_step

@feature_step()
def feature_engineering(df, context):
    df["ratio"] = df["amount"] / df["customer_limit"]
    df["high_risk"] = (df["amount"] > 500).astype(int)
    return df
```

## Example 2 - Scoring file with pickle model

```python
from fraud_platform_spark import scoring_step

@scoring_step()
def scoring(df, context):
    import pandas as pd
    from pyspark.sql.functions import pandas_udf

    model_bc = context["model"]

    @pandas_udf("double")
    def predict_udf(ratio, high_risk):
        model = model_bc.value
        X = pd.DataFrame({
            "ratio": ratio,
            "high_risk": high_risk
        })
        return pd.Series(model.predict_proba(X)[:, 1])

    sdf = df.to_spark(index_col=None).withColumn(
        "score",
        predict_udf("ratio", "high_risk")
    )
    scored = sdf.pandas_api()
    scored["prediction"] = (scored["score"] > 0.75).astype(int)
    return scored
```

## Example 3 - Driver script

```python
from fraud_platform_spark import run_pipeline

import my_features
import my_scoring

QUERY = """
SELECT
    account_id,
    amount,
    customer_limit
FROM fraud_db.transactions
WHERE txn_date >= '2025-01-01'
"""

result_df = run_pipeline(
    query=QUERY,
    model_path="/path/to/model.pkl",
    metadata={"score_cutoff": 0.75},
)
result_df.show(20, truncate=False)
```

## Run on YARN

```bash
spark-submit \
  --master yarn \
  --deploy-mode cluster \
  --queue fraud_queue \
  --num-executors 10 \
  --executor-memory 8g \
  --executor-cores 4 \
  --driver-memory 4g \
  --conf spark.sql.shuffle.partitions=200 \
  --conf spark.pyspark.python=/usr/bin/python3.7 \
  --conf spark.pyspark.driver.python=/usr/bin/python3.7 \
  --py-files fraud_platform_spark-0.4.0-py3-none-any.whl \
  demo.py
```

## Guardrails

The framework blocks these patterns inside user-defined steps:

- `df.to_pandas()`
- `df.collect()`
- `df.apply(..., axis=1)`
- row iteration
- `pickle.load()`
- `joblib.load()`

## Important note

The user should **not** load the pickle model inside scoring code.
The framework loads the model once on the driver and broadcasts it to Spark executors.
