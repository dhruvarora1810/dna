from fraud_platform_spark import feature_step


@feature_step()
def feature_engineering(df, context):
    df["ratio"] = df["amount"] / df["customer_limit"]
    df["high_risk"] = (df["amount"] > 500).astype(int)
    df["amount_bucket"] = "LOW"
    df.loc[df["amount"] > 300, "amount_bucket"] = "MEDIUM"
    df.loc[df["amount"] > 700, "amount_bucket"] = "HIGH"
    return df
