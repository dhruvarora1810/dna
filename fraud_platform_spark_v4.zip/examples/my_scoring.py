from fraud_platform_spark import scoring_step


@scoring_step()
def scoring(df, context):
    import pandas as pd
    from pyspark.sql.functions import pandas_udf

    model_bc = context.get("model")
    if model_bc is None:
        raise ValueError("No broadcast model found in context. Pass model_path to run_pipeline or run_scoring_pipeline.")

    @pandas_udf("double")
    def predict_udf(ratio, high_risk):
        model = model_bc.value
        X = pd.DataFrame({
            "ratio": ratio,
            "high_risk": high_risk,
        })
        return pd.Series(model.predict_proba(X)[:, 1])

    score_sdf = df.to_spark(index_col=None).withColumn(
        "score",
        predict_udf("ratio", "high_risk")
    )

    scored = score_sdf.pandas_api()
    scored["prediction"] = (scored["score"] > 0.75).astype(int)
    return scored
