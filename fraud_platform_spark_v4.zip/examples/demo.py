from fraud_platform_spark import run_pipeline

import my_features  # noqa: F401
import my_scoring   # noqa: F401


QUERY = """
SELECT
    account_id,
    amount,
    customer_limit
FROM fraud_db.transactions
WHERE txn_date >= '2025-01-01'
"""


if __name__ == "__main__":
    result_df = run_pipeline(
        query=QUERY,
        model_path="/path/to/model.pkl",
        metadata={"score_cutoff": 0.75},
        explain_plan=True,
    )
    result_df.show(10, truncate=False)
