# fraud-platform-spark v4

Spark-native framework for distributed feature engineering and model scoring using:
- SQL query input
- Python-only feature engineering code
- Python-only scoring code
- optional pickle model loading with Spark broadcast

## End-user workflow

1. Provide a SQL query
2. Write feature engineering Python code using `@feature_step()`
3. Write scoring Python code using `@scoring_step()`
4. Run `run_pipeline(query=..., model_path=...)`

## Guardrails

The framework blocks unsafe patterns such as:
- `.to_pandas()`
- `.collect()`
- `.apply(..., axis=1)`
- `pickle.load()` inside feature/scoring steps
- `joblib.load()` inside feature/scoring steps

## Example usage

See `examples/`.
