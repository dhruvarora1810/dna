from __future__ import annotations

from typing import Any, Dict, Optional

import pyspark.pandas as ps
from pyspark.sql import SparkSession, DataFrame as SparkDataFrame

from fraud_platform_spark.registry import get_feature_steps, get_scoring_steps
from fraud_platform_spark.state import PipelineState
from fraud_platform_spark.validators import validate_step_source


def _log(message):
    print("[fraud-platform-spark] {0}".format(message))


def get_spark(app_name="FraudPlatformSparkV4"):
    active = SparkSession.getActiveSession()
    if active is not None:
        return active

    spark = (
        SparkSession.builder
        .appName(app_name)
        .enableHiveSupport()
        .getOrCreate()
    )
    return spark


def _ensure_ps_defaults():
    try:
        ps.set_option("compute.default_index_type", "distributed")
    except Exception:
        pass


def load_model_as_broadcast(spark, model_path):
    import pickle

    with open(model_path, "rb") as handle:
        model = pickle.load(handle)

    return spark.sparkContext.broadcast(model)


def load_context(spark, model_path=None, extra_context=None):
    context = dict(extra_context or {})
    if model_path:
        _log("Loading model from pickle: {0}".format(model_path))
        context["model"] = load_model_as_broadcast(spark, model_path)
        context["model_path"] = model_path
    return context


def _run_steps(psdf, steps, state):
    for step in steps:
        validate_step_source(step)
        _log("Running step: {0}".format(getattr(step, "__name__", "unknown")))
        result = step(psdf, state.context)
        if result is None:
            raise TypeError("Step '{0}' returned None. Each step must return a dataframe.".format(
                getattr(step, "__name__", "unknown")
            ))
        psdf = result
        state.data = psdf
    return state


def run_feature_pipeline(query, metadata=None, extra_context=None, explain_plan=False):
    spark = get_spark()
    _ensure_ps_defaults()

    steps = get_feature_steps()
    if not steps:
        raise RuntimeError("No feature steps registered. Import the user feature module before running the pipeline.")

    _log("Executing Spark SQL query")
    _log(query.strip())
    spark_df = spark.sql(query)

    if explain_plan:
        _log("Initial Spark plan:")
        spark_df.explain(True)

    psdf = spark_df.pandas_api()
    state = PipelineState(
        data=psdf,
        metadata=dict(metadata or {}),
        artifacts={},
        context=load_context(spark, extra_context=extra_context),
    )

    state = _run_steps(psdf, steps, state)
    return state


def run_scoring_pipeline(state, model_path=None, extra_context=None, explain_plan=False):
    spark = get_spark()
    _ensure_ps_defaults()

    steps = get_scoring_steps()
    if not steps:
        raise RuntimeError("No scoring steps registered. Import the user scoring module before running the pipeline.")

    context = dict(state.context or {})
    if extra_context:
        context.update(extra_context)

    if model_path:
        context["model"] = load_model_as_broadcast(spark, model_path)
        context["model_path"] = model_path

    state.context = context
    psdf = state.data
    state = _run_steps(psdf, steps, state)

    spark_df = state.data.to_spark(index_col=None)

    if explain_plan:
        _log("Final Spark plan:")
        spark_df.explain(True)

    state.data = spark_df
    return state


def run_pipeline(query, model_path=None, metadata=None, extra_context=None, explain_plan=False):
    feature_state = run_feature_pipeline(
        query=query,
        metadata=metadata,
        extra_context=extra_context,
        explain_plan=explain_plan,
    )
    scored_state = run_scoring_pipeline(
        feature_state,
        model_path=model_path,
        extra_context=extra_context,
        explain_plan=explain_plan,
    )
    return scored_state.data


def save_as_table(df, table_name, mode="overwrite"):
    spark_df = df if isinstance(df, SparkDataFrame) else df.to_spark(index_col=None)
    _log("Writing output to table: {0} (mode={1})".format(table_name, mode))
    spark_df.write.mode(mode).saveAsTable(table_name)
