from __future__ import annotations

from typing import Callable, List

_FEATURE_STEPS = []  # type: List[Callable]
_SCORING_STEPS = []  # type: List[Callable]


def feature_step():
    def decorator(func):
        _FEATURE_STEPS.append(func)
        return func
    return decorator


def scoring_step():
    def decorator(func):
        _SCORING_STEPS.append(func)
        return func
    return decorator


def get_feature_steps():
    return list(_FEATURE_STEPS)


def get_scoring_steps():
    return list(_SCORING_STEPS)


def clear_registry():
    _FEATURE_STEPS[:] = []
    _SCORING_STEPS[:] = []
