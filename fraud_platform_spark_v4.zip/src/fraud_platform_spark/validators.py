from __future__ import annotations

import inspect

FORBIDDEN_PATTERNS = [
    ".to_pandas(",
    ".collect(",
    ".apply(",
    "axis=1",
    ".iterrows(",
    ".itertuples(",
    "pickle.load(",
    "joblib.load(",
]


def validate_step_source(func):
    try:
        src = inspect.getsource(func)
    except (OSError, IOError, TypeError):
        return

    violations = [p for p in FORBIDDEN_PATTERNS if p in src]
    if violations:
        raise ValueError(
            "Step '{name}' contains forbidden patterns for distributed execution: {violations}".format(
                name=getattr(func, "__name__", "unknown"),
                violations=violations,
            )
        )
