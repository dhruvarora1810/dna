# fraud-platform-spark v5

Spark-native, Python-first framework for dispute feature engineering and scoring.

## What users provide
1. SQL query
2. Python feature engineering code
3. Python scoring code
4. Optional pickle model

## How it runs
The framework executes the SQL on Spark, converts to pandas-on-Spark for user-authored code, broadcasts the model, executes scoring via pandas UDF, and returns a Spark DataFrame.
