from typing import Callable, List

_FEATURE_STEPS = []  # type: List[Callable]
_SCORING_STEPS = []  # type: List[Callable]


def feature_step(func=None):
    def decorator(f):
        _FEATURE_STEPS.append(f)
        return f
    return decorator(func) if func else decorator


def scoring_step(func=None):
    def decorator(f):
        _SCORING_STEPS.append(f)
        return f
    return decorator(func) if func else decorator


def get_feature_steps():
    return list(_FEATURE_STEPS)


def get_scoring_steps():
    return list(_SCORING_STEPS)


def clear_registry():
    _FEATURE_STEPS[:] = []
    _SCORING_STEPS[:] = []
