from dataclasses import dataclass, field
from typing import Any, Dict


@dataclass
class PipelineState:
    data: Any
    metadata: Dict[str, Any] = field(default_factory=dict)
    artifacts: Dict[str, Any] = field(default_factory=dict)
