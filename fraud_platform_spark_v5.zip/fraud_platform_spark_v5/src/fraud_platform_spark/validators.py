import inspect

FORBIDDEN_PATTERNS = [
    '.collect(',
    '.toPandas(',
    '.to_pandas(',
    '.iterrows(',
    '.itertuples(',
    'axis=1',
    'pickle.load(',
    'joblib.load(',
]


def validate_user_function(func):
    try:
        src = inspect.getsource(func)
    except (OSError, IOError):
        return
    bad = [p for p in FORBIDDEN_PATTERNS if p in src]
    if bad:
        raise ValueError(
            "Forbidden patterns found in %s: %s. Use Spark-safe / pandas-on-Spark-safe logic only." % (func.__name__, bad)
        )
