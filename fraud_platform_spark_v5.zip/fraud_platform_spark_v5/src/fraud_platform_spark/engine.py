from __future__ import print_function
import importlib.util
import os
import pickle
from typing import Dict, Optional

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

from fraud_platform_spark.registry import get_feature_steps, get_scoring_steps, clear_registry
from fraud_platform_spark.state import PipelineState
from fraud_platform_spark.validators import validate_user_function


def get_spark(app_name='fraud-platform-spark-v5'):
    spark = SparkSession.getActiveSession()
    if spark is not None:
        return spark
    return SparkSession.builder.appName(app_name).enableHiveSupport().getOrCreate()


def log(msg):
    print('[fraud-platform-spark] %s' % msg)


def load_python_module(path, module_name=None):
    path = os.path.abspath(path)
    if module_name is None:
        module_name = os.path.splitext(os.path.basename(path))[0]
    spec = importlib.util.spec_from_file_location(module_name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def load_model(model_path):
    with open(model_path, 'rb') as f:
        return pickle.load(f)


def load_model_broadcast(spark, model_path):
    model = load_model(model_path)
    return spark.sparkContext.broadcast(model)


def _prepare_context(spark, metadata=None, model_path=None, extra_artifacts=None):
    metadata = metadata or {}
    artifacts = extra_artifacts.copy() if extra_artifacts else {}
    if model_path:
        artifacts['model'] = load_model_broadcast(spark, model_path)
        artifacts['model_path'] = model_path
    return metadata, artifacts


def _run_pandas_on_spark_steps(psdf, steps, metadata, artifacts):
    for step in steps:
        validate_user_function(step)
        log('Running %s' % step.__name__)
        psdf = step(psdf, {'metadata': metadata, 'artifacts': artifacts})
    return psdf


def run_pipeline(query,
                 feature_code_path=None,
                 scoring_code_path=None,
                 model_path=None,
                 output_table=None,
                 metadata=None,
                 app_name='fraud-platform-spark-v5',
                 show_rows=20):
    spark = get_spark(app_name)
    clear_registry()

    if feature_code_path:
        load_python_module(feature_code_path, 'user_feature_code')
    if scoring_code_path:
        load_python_module(scoring_code_path, 'user_scoring_code')

    feature_steps = get_feature_steps()
    scoring_steps = get_scoring_steps()

    log('Executing SQL input query')
    sdf = spark.sql(query)
    log('Input row count preview request')
    sdf.show(min(show_rows, 5), truncate=False)

    metadata, artifacts = _prepare_context(spark, metadata=metadata, model_path=model_path)

    # pandas-on-Spark path for user-authored code
    import pandas as pd
    if not hasattr(pd.DataFrame, 'iteritems'):
        pd.DataFrame.iteritems = pd.DataFrame.items
    import pyspark.pandas as ps
    ps.set_option('compute.default_index_type', 'distributed')

    psdf = sdf.pandas_api()

    if feature_steps:
        psdf = _run_pandas_on_spark_steps(psdf, feature_steps, metadata, artifacts)
    if scoring_steps:
        psdf = _run_pandas_on_spark_steps(psdf, scoring_steps, metadata, artifacts)

    out_sdf = psdf.to_spark()

    if output_table:
        log('Writing output to table %s' % output_table)
        out_sdf.write.mode('overwrite').saveAsTable(output_table)

    return out_sdf
