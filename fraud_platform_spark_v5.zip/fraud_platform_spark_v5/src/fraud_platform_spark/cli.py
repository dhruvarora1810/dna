import argparse
import json

from fraud_platform_spark.engine import run_pipeline


def main():
    p = argparse.ArgumentParser(description='fraud-platform-spark-v5')
    p.add_argument('--sql-file', required=True)
    p.add_argument('--feature-code', required=True)
    p.add_argument('--scoring-code', required=True)
    p.add_argument('--model-path')
    p.add_argument('--output-table')
    p.add_argument('--metadata-json')
    p.add_argument('--show-rows', type=int, default=20)
    args = p.parse_args()

    with open(args.sql_file) as f:
        query = f.read()

    metadata = json.loads(args.metadata_json) if args.metadata_json else None

    df = run_pipeline(
        query=query,
        feature_code_path=args.feature_code,
        scoring_code_path=args.scoring_code,
        model_path=args.model_path,
        output_table=args.output_table,
        metadata=metadata,
        show_rows=args.show_rows,
    )
    df.show(args.show_rows, truncate=False)


if __name__ == '__main__':
    main()
