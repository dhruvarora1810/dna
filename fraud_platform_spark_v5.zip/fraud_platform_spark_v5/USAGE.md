# Fraud Platform Spark v5 - Usage

## Business use case
Score fraud dispute cases from `gcgdlknapsg_fraud_wkstation_t_db.fraud_case_detail` using user-provided SQL, feature code, and scoring code.

## Folder
`examples/dispute_demo`

## Files
- `query.sql` - SQL input
- `feature_code.py` - feature engineering logic
- `scoring_code.py` - model scoring logic
- `train_mock_model.py` - creates a demo pickle model
- `run_demo.py` - end-to-end entry point

## 1. Build demo model
```bash
cd examples/dispute_demo
python train_mock_model.py
```

## 2. Package the runtime environment
```bash
conda pack -n spark_pandas_env -o spark_env.tar.gz
```

## 3. Run with Spark 3 on Citi
Use Spark 3 submit, not generic `spark-submit`.

```bash
spark3-submit \
  --master yarn \
  --deploy-mode client \
  --queue <YOUR_QUEUE> \
  --archives spark_env.tar.gz#env \
  --conf spark.pyspark.python=./env/bin/python \
  --conf spark.pyspark.driver.python=$(which python) \
  --conf spark.yarn.appMasterEnv.PYSPARK_PYTHON=./env/bin/python \
  --conf spark.executorEnv.PYSPARK_PYTHON=./env/bin/python \
  run_demo.py
```

## 4. Expected output
Output includes:
- `fraud_probability`
- `fraud_prediction`
- `priority_band`

## Guardrails
The framework blocks these patterns in user code:
- `.collect(`
- `.toPandas(`
- `.to_pandas(`
- `.iterrows(`
- `.itertuples(`
- `axis=1`
- `pickle.load(` inside user scoring code
- `joblib.load(` inside user scoring code

## End-user contract
Users only write Python functions and SQL. They do not need to write Spark session logic.
