from fraud_platform_spark import run_pipeline


def main():
    with open('query.sql') as f:
        query = f.read()

    df = run_pipeline(
        query=query,
        feature_code_path='feature_code.py',
        scoring_code_path='scoring_code.py',
        model_path='fraud_dispute_model.pkl',
        metadata={
            'high_amount_threshold': 500.0,
            'fraud_cutoff': 0.65,
        },
        show_rows=10,
    )

    df.select(
        'acct_num', 'fraud_caseid', 'case_status', 'amount_num',
        'raw_rule_score', 'fraud_probability', 'fraud_prediction', 'priority_band'
    ).show(25, truncate=False)


if __name__ == '__main__':
    main()
