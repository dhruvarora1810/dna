from fraud_platform_spark import feature_step


@feature_step()
def build_dispute_features(df, context):
    md = context.get('metadata', {})
    amount_threshold = md.get('high_amount_threshold', 500.0)

    df['amount_num'] = df['delinquencyadjustedamount'].fillna(0.0).astype(float)
    df['high_amount_flag'] = (df['amount_num'] > amount_threshold).astype(int)
    df['is_pending'] = df['case_status'].fillna('').str.upper().isin(['PENDING', 'OPEN']).astype(int)
    df['has_callback'] = df['returncall_reason'].notna().astype(int)
    df['digital_channel_flag'] = df['activity_mode'].fillna('').str.upper().isin(['ONLINE', 'MOBILE', 'APP']).astype(int)
    df['ec_high_flag'] = df['ec_code'].fillna('').str.upper().isin(['HIGH', 'CRITICAL', 'H']).astype(int)
    df['raw_rule_score'] = (
        df['high_amount_flag'] * 2
        + df['is_pending']
        + df['has_callback']
        + df['digital_channel_flag']
        + df['ec_high_flag']
    )
    return df
