from fraud_platform_spark import scoring_step
import pandas as pd
from pyspark.sql.functions import pandas_udf


@scoring_step()
def score_disputes(df, context):
    model_bc = context.get('artifacts', {}).get('model')
    score_cutoff = context.get('metadata', {}).get('fraud_cutoff', 0.65)

    @pandas_udf('double')
    def predict_udf(high_amount_flag, is_pending, has_callback, digital_channel_flag, ec_high_flag):
        model = model_bc.value
        X = pd.DataFrame({
            'high_amount_flag': high_amount_flag,
            'is_pending': is_pending,
            'has_callback': has_callback,
            'digital_channel_flag': digital_channel_flag,
            'ec_high_flag': ec_high_flag,
        })
        return pd.Series(model.predict_proba(X)[:, 1])

    df['fraud_probability'] = predict_udf(
        df['high_amount_flag'],
        df['is_pending'],
        df['has_callback'],
        df['digital_channel_flag'],
        df['ec_high_flag'],
    )
    df['fraud_prediction'] = (df['fraud_probability'] >= score_cutoff).astype(int)
    df['priority_band'] = 'LOW'
    df.loc[df['fraud_probability'] >= 0.50, 'priority_band'] = 'MEDIUM'
    df.loc[df['fraud_probability'] >= 0.80, 'priority_band'] = 'HIGH'
    return df
