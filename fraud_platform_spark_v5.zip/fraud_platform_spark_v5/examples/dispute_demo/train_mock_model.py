import pickle
import pandas as pd
from sklearn.linear_model import LogisticRegression

train = pd.DataFrame({
    'high_amount_flag': [0,1,1,0,1,0,1,1],
    'is_pending': [0,1,1,0,1,1,0,1],
    'has_callback': [0,1,0,0,1,0,1,1],
    'digital_channel_flag': [0,1,1,0,0,1,1,1],
    'ec_high_flag': [0,1,0,0,1,0,1,1],
    'target': [0,1,1,0,1,0,1,1],
})

X = train[['high_amount_flag','is_pending','has_callback','digital_channel_flag','ec_high_flag']]
y = train['target']

model = LogisticRegression()
model.fit(X, y)

with open('fraud_dispute_model.pkl', 'wb') as f:
    pickle.dump(model, f)

print('Saved fraud_dispute_model.pkl')
