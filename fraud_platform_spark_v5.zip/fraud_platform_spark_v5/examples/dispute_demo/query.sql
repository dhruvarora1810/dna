SELECT
    acct_num,
    case_status,
    report_type,
    returncall_reason,
    activity_mode,
    ec_code,
    delinquencyadjustedamount,
    fraud_caseid,
    audit_load_dt
FROM gcgdlknapsg_fraud_wkstation_t_db.fraud_case_detail
WHERE audit_load_dt >= 20240101
LIMIT 1000
