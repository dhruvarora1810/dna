#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# build.sh — builds conda and pip packages for fraud-platform
#
# Usage:
#   ./build.sh                          # build both (conda + pip)
#   ./build.sh pip                      # pip wheel + sdist only
#   ./build.sh conda                    # conda package only
#
# Publish:
#   UPLOAD=private ./build.sh conda     # upload to private Anaconda repo
#   UPLOAD=pypi    ./build.sh pip       # upload to PyPI
#
# Required env vars for publishing:
#   ANACONDA_TOKEN    — from anaconda.org → Account Settings → Access
#   ANACONDA_CHANNEL  — your org or personal channel name
#   TWINE_USERNAME    — PyPI username (use __token__ for API token auth)
#   TWINE_PASSWORD    — PyPI password or API token
# ─────────────────────────────────────────────────────────────────────────────

set -e

MODE=${1:-"both"}

build_pip() {
    echo ""
    echo "==> Building pip package (sdist + wheel)..."
    pip install --quiet build twine
    python -m build
    echo "==> Pip packages built:"
    ls dist/

    if [ "$UPLOAD" = "pypi" ]; then
        echo "==> Uploading to PyPI..."
        twine upload dist/*
        echo "==> Done. Install with: pip install fraud-platform"
    elif [ "$UPLOAD" = "testpypi" ]; then
        echo "==> Uploading to TestPyPI..."
        twine upload --repository testpypi dist/*
        echo "==> Test install: pip install -i https://test.pypi.org/simple/ fraud-platform"
    fi
}

build_conda() {
    echo ""
    echo "==> Building conda package..."
    conda install -y -q conda-build conda-verify anaconda-client
    conda build conda/ --output-folder conda-bld/
    echo "==> Conda packages built:"
    ls conda-bld/noarch/

    if [ "$UPLOAD" = "private" ]; then
        if [ -z "$ANACONDA_TOKEN" ] || [ -z "$ANACONDA_CHANNEL" ]; then
            echo "ERROR: Set ANACONDA_TOKEN and ANACONDA_CHANNEL env vars first."
            exit 1
        fi
        echo "==> Uploading to private Anaconda repo (channel: $ANACONDA_CHANNEL)..."
        anaconda -t "$ANACONDA_TOKEN" upload \
            --user "$ANACONDA_CHANNEL" \
            --force \
            conda-bld/noarch/fraud-platform-*.conda
        echo ""
        echo "==> Install from your private repo:"
        echo "    conda install -c https://conda.anaconda.org/$ANACONDA_CHANNEL fraud-platform"

    elif [ "$UPLOAD" = "conda-forge" ]; then
        echo ""
        echo "==> conda-forge requires a PR (no direct upload for first submission):"
        echo "    1. Fork https://github.com/conda-forge/staged-recipes"
        echo "    2. Copy conda/meta.yaml to recipes/fraud-platform/meta.yaml"
        echo "    3. Update source: block to use PyPI url + sha256"
        echo "    4. Open a PR — conda-forge bot reviews and publishes"
        echo "    5. After merge: conda install -c conda-forge fraud-platform"
    fi
}

case "$MODE" in
    pip)   build_pip ;;
    conda) build_conda ;;
    both)  build_pip; build_conda ;;
    *)     echo "Unknown mode: $MODE. Use: pip | conda | both"; exit 1 ;;
esac

echo ""
echo "✓ Build complete"
