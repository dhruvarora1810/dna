"""
Step registration decorators.

Data scientists use these decorators to register their functions
with the pipeline. The framework reads these lists at run time.

Usage:
    from fraud_platform import feature_step, training_step, PipelineState

    @feature_step
    def my_feature(state: PipelineState) -> PipelineState:
        df = state.data.copy()
        df["col"] = ...
        return state.clone_with(data=df)

    @training_step
    def my_model(state: PipelineState) -> PipelineState:
        model = SomeClassifier().fit(X, y)
        return state.clone_with(artifacts={"model": model})

Execution order:
    Steps run in registration order — which is the order they appear
    in your file from top to bottom. If step B depends on a column
    created by step A, define step A first.

Important:
    Your features file must be imported before run_feature_pipeline()
    is called. The decorators register functions at import time.

        import my_fraud_features        # registers all steps
        from fraud_platform import run_feature_pipeline
        result = run_feature_pipeline(df)
"""

from __future__ import annotations
from typing import Callable

_FEATURE_STEPS: list[Callable] = []
_TRAINING_STEPS: list[Callable] = []


def feature_step(fn: Callable) -> Callable:
    """
    Register a function as a distributed feature engineering step.

    The function will be executed on Dask workers, one pandas batch
    at a time. It must accept and return a PipelineState.

    Args:
        fn: A function with signature (PipelineState) -> PipelineState

    Returns:
        The original function, unmodified.
    """
    _FEATURE_STEPS.append(fn)
    return fn


def training_step(fn: Callable) -> Callable:
    """
    Register a function as a training step.

    Training steps run on the driver (not distributed) and receive
    the full enriched dataset. Use them to fit models, encoders,
    or scalers and store results in state.artifacts.

    Args:
        fn: A function with signature (PipelineState) -> PipelineState

    Returns:
        The original function, unmodified.
    """
    _TRAINING_STEPS.append(fn)
    return fn


def get_feature_steps() -> list[Callable]:
    """Return all registered feature steps in registration order."""
    return list(_FEATURE_STEPS)


def get_training_steps() -> list[Callable]:
    """Return all registered training steps in registration order."""
    return list(_TRAINING_STEPS)
