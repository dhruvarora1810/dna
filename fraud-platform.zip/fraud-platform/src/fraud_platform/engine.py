"""
Dask distributed execution engine.

Handles all distributed computing logic. Data scientists never
import from this module directly.

Environment-based cluster detection:
    Local (no env var set):
        Uses Dask's local threaded scheduler.
        Zero config. Runs on all CPU cores on the current machine.

    OpenShift / Kubernetes (DASK_SCHEDULER_ADDRESS set):
        Connects to a remote Dask scheduler service.
        No code change needed — just set the env var.

        export DASK_SCHEDULER_ADDRESS=tcp://<scheduler-ip>:8786

How distributed execution works:
    1. DataFrame is split into N partitions (chunks)
    2. Each partition is sent to a Dask worker
    3. Each worker runs ALL feature steps on its partition
       (DS functions only see plain pandas DataFrames)
    4. Results are collected and concatenated back on the driver
    5. Training steps then run on the driver with the full dataset
"""

from __future__ import annotations
import os
import pandas as pd
import dask.dataframe as dd
from distributed import Client
from fraud_platform.state import PipelineState
from fraud_platform.registry import get_feature_steps, get_training_steps
from typing import Callable


def _get_client() -> Client | None:
    """
    Auto-detect execution environment.

    Returns a Dask Client connected to a remote cluster if
    DASK_SCHEDULER_ADDRESS is set, otherwise returns None
    (Dask uses local threads automatically).
    """
    scheduler = os.environ.get("DASK_SCHEDULER_ADDRESS")
    if scheduler:
        print(f"[fraud-platform] Connecting to Dask cluster: {scheduler}")
        return Client(scheduler)
    print("[fraud-platform] No DASK_SCHEDULER_ADDRESS set — running locally")
    return None


def _apply_steps_to_partition(
    partition: pd.DataFrame,
    steps: list[Callable],
    metadata: dict,
) -> pd.DataFrame:
    """
    Executed on each Dask worker for each partition.

    Reconstructs a PipelineState from the partition, runs all
    feature steps sequentially, and returns the transformed DataFrame.
    DS functions run here — they only ever see a pandas DataFrame.

    Args:
        partition: One chunk of the full DataFrame
        steps:     All registered feature step functions
        metadata:  Config dict from the pipeline caller

    Returns:
        Transformed pandas DataFrame with new feature columns added.
    """
    state = PipelineState(data=partition, metadata=metadata)
    for step in steps:
        state = step(state)
    return state.data


def run_feature_pipeline(
    df: pd.DataFrame,
    steps: list[Callable] | None = None,
    n_partitions: int | None = None,
    metadata: dict | None = None,
) -> PipelineState:
    """
    Distribute feature engineering across Dask workers.

    Splits the input DataFrame into partitions, sends each partition
    to a Dask worker, runs all feature steps, then reassembles the
    results. Works locally (threads) or on a remote cluster (set
    DASK_SCHEDULER_ADDRESS).

    Args:
        df:            Raw input DataFrame
        steps:         Feature step functions to run. Defaults to all
                       functions registered with @feature_step.
                       Override this in tests to run specific steps.
        n_partitions:  Number of chunks to split the DataFrame into.
                       Rule of thumb: n_workers x 4.
                       Defaults to 8 locally, auto-scales on cluster.
        metadata:      Arbitrary config dict passed into state.metadata
                       for all steps to read (thresholds, lookup lists etc.)

    Returns:
        PipelineState with enriched data in .data field.

    Raises:
        RuntimeError: If no feature steps are registered and steps=None.

    Example:
        result = run_feature_pipeline(
            df=transactions_df,
            metadata={"large_txn_threshold": 500},
        )
        enriched_df = result.data
    """
    steps = steps or get_feature_steps()
    metadata = metadata or {}

    if not steps:
        raise RuntimeError(
            "No feature steps registered. "
            "Did you import your features file before calling run_feature_pipeline()?\n\n"
            "    import my_fraud_features   # add this line before run_feature_pipeline()"
        )

    client = _get_client()

    # Auto-detect partition count based on cluster size
    if n_partitions is None:
        if client:
            n_workers = len(client.scheduler_info().get("workers", {}))
            n_partitions = max(n_workers * 4, 8)
        else:
            n_partitions = 8

    # Split into Dask DataFrame (lazy — nothing runs yet)
    ddf = dd.from_pandas(df, npartitions=n_partitions)

    # Run one sample batch locally so Dask knows the output column schema
    # before distributing. Required for map_partitions meta inference.
    sample = _apply_steps_to_partition(df.head(100).copy(), steps, metadata)
    meta = sample.iloc[0:0]  # empty DataFrame, correct dtypes

    # Schedule work across workers (still lazy)
    result_ddf = ddf.map_partitions(
        _apply_steps_to_partition,
        steps=steps,
        metadata=metadata,
        meta=meta,
    )

    # .compute() triggers execution — this is where Dask actually runs
    result_df = result_ddf.compute()

    if client:
        client.close()

    return PipelineState(
        data=result_df.reset_index(drop=True),
        metadata=metadata,
    )


def run_training_pipeline(
    state: PipelineState,
    steps: list[Callable] | None = None,
) -> PipelineState:
    """
    Run training steps sequentially on the driver.

    Training is intentionally not distributed — model fitting
    requires the full dataset in one place. If you need distributed
    training (e.g. XGBoost on a cluster), use the library's own
    distributed API inside your @training_step.

    Args:
        state: PipelineState output from run_feature_pipeline()
        steps: Training step functions to run. Defaults to all
               functions registered with @training_step.

    Returns:
        PipelineState with trained model in .artifacts and
        evaluation metrics in .metadata.

    Example:
        final = run_training_pipeline(feature_state)
        model = final.artifacts["model"]
        auc   = final.metadata["val_auc"]
    """
    steps = steps or get_training_steps()
    for step in steps:
        state = step(state)
    return state
