"""
PipelineState — the DTO that flows through every pipeline step.

Data scientists interact with this object in every step they write:

    def my_step(state: PipelineState) -> PipelineState:
        df = state.data.copy()       # read the data
        df["my_col"] = ...           # transform it
        return state.clone_with(data=df)  # return updated state

Fields:
    data      — the pandas DataFrame (your rows and columns)
    metadata  — dict of config/thresholds passed in at pipeline start
    artifacts — dict for storing trained models, encoders, scalers
"""

from __future__ import annotations
from dataclasses import dataclass, field
import pandas as pd
from typing import Any


@dataclass
class PipelineState:
    """
    Immutable-style container that carries data between pipeline steps.

    Never modify fields directly. Always use clone_with() to produce
    an updated copy — this prevents subtle bugs in distributed execution.

    Example:
        state = PipelineState(data=df, metadata={"threshold": 500})
        new_state = state.clone_with(data=enriched_df)
    """

    data: pd.DataFrame
    metadata: dict[str, Any] = field(default_factory=dict)
    artifacts: dict[str, Any] = field(default_factory=dict)

    def clone_with(self, **kwargs) -> PipelineState:
        """
        Return a new PipelineState with the given fields overridden.

        metadata and artifacts are shallow-merged (existing keys preserved,
        new keys added or overwritten).

        Args:
            data:      replacement DataFrame
            metadata:  dict to merge into current metadata
            artifacts: dict to merge into current artifacts

        Returns:
            New PipelineState instance.
        """
        return PipelineState(
            data=kwargs.get("data", self.data),
            metadata={**self.metadata, **kwargs.get("metadata", {})},
            artifacts={**self.artifacts, **kwargs.get("artifacts", {})},
        )
