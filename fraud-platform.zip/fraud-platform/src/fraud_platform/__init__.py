"""
fraud-platform
==============
Distributed fraud feature engineering framework.

Data scientists import only from here:

    from fraud_platform import (
        PipelineState,
        feature_step,
        training_step,
        run_feature_pipeline,
        run_training_pipeline,
    )

Quickstart
----------
1. Write your feature functions in a .py file:

    from fraud_platform import feature_step, PipelineState

    @feature_step
    def flag_large_transaction(state: PipelineState) -> PipelineState:
        df = state.data.copy()
        df["is_large"] = (df["amount"] > 500).astype(int)
        return state.clone_with(data=df)

2. Import that file and run the pipeline:

    import my_features  # registers all @feature_step functions
    from fraud_platform import run_feature_pipeline

    result = run_feature_pipeline(df)
    print(result.data.head())

3. To run on OpenShift, just set one env var — no code change:

    export DASK_SCHEDULER_ADDRESS=tcp://<scheduler-ip>:8786
    python run.py
"""

from fraud_platform.state import PipelineState
from fraud_platform.registry import feature_step, training_step
from fraud_platform.engine import run_feature_pipeline, run_training_pipeline

__version__ = "0.1.0"
__all__ = [
    "PipelineState",
    "feature_step",
    "training_step",
    "run_feature_pipeline",
    "run_training_pipeline",
]
