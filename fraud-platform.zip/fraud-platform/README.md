# fraud-platform

Distributed fraud feature engineering framework. Write features, not pipelines.

---

## What it does

Lets data scientists write plain pandas functions. The framework runs them
distributed across a Dask cluster — locally or on OpenShift — automatically.

```python
from fraud_platform import feature_step, PipelineState

@feature_step
def flag_large_transaction(state: PipelineState) -> PipelineState:
    df = state.data.copy()
    df["is_large"] = (df["amount"] > 500).astype(int)
    return state.clone_with(data=df)
```

That's it. No Dask, no batching, no cluster config needed from the DS.

---

## Install

### conda (recommended)
```bash
# Private Anaconda repo
conda install -c https://conda.anaconda.org/<your-channel> fraud-platform

# conda-forge (after public release)
conda install -c conda-forge fraud-platform

# With model libraries
conda install -c conda-forge fraud-platform xgboost lightgbm
```

### pip
```bash
pip install fraud-platform
pip install "fraud-platform[xgboost]"
pip install "fraud-platform[lightgbm]"
pip install "fraud-platform[all-models]"
```

### Local dev (editable)
```bash
git clone https://github.com/your-org/fraud-platform
cd fraud-platform
pip install -e ".[dev]"
pytest tests/ -v
```

---

## Quickstart

**1. Write your features** (`my_features.py`):
```python
import pandas as pd
from fraud_platform import feature_step, training_step, PipelineState

@feature_step
def compute_amount_zscore(state: PipelineState) -> PipelineState:
    df = state.data.copy()
    grp = df.groupby("card_id")["amount"].transform
    df["amount_zscore"] = (df["amount"] - grp("mean")) / (grp("std") + 1e-6)
    return state.clone_with(data=df)

@training_step
def train_model(state: PipelineState) -> PipelineState:
    from sklearn.ensemble import GradientBoostingClassifier  # swap for any model
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import roc_auc_score

    FEATURES = ["amount_zscore"]
    X, y = state.data[FEATURES], state.data["is_fraud"]
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2)

    model = GradientBoostingClassifier().fit(X_train, y_train)
    auc = roc_auc_score(y_val, model.predict_proba(X_val)[:, 1])

    return state.clone_with(
        artifacts={"model": model},
        metadata={"val_auc": round(auc, 4)},
    )
```

**2. Run the pipeline** (`run.py`):
```python
import my_features  # registers all @feature_step / @training_step
from fraud_platform import run_feature_pipeline, run_training_pipeline
from fraud_platform.registry import get_feature_steps, get_training_steps

feature_state = run_feature_pipeline(df, steps=get_feature_steps())
final_state   = run_training_pipeline(feature_state, steps=get_training_steps())

print(final_state.metadata["val_auc"])
model = final_state.artifacts["model"]
```

---

## Run on OpenShift

No code changes needed. Set one env var:
```bash
oc apply -f openshift/dask-cluster.yaml
export DASK_SCHEDULER_ADDRESS=tcp://$(oc get svc dask-scheduler -o jsonpath='{.spec.clusterIP}'):8786
python run.py
```

---

## Supported models

| Library   | conda                      | pip extra                          |
|-----------|----------------------------|------------------------------------|
| sklearn   | included                   | included                           |
| XGBoost   | `conda install xgboost`    | `pip install fraud-platform[xgboost]`  |
| LightGBM  | `conda install lightgbm`   | `pip install fraud-platform[lightgbm]` |
| CatBoost  | `conda install catboost`   | `pip install fraud-platform[catboost]` |

Swap the model in one line — nothing else changes:
```python
from xgboost import XGBClassifier       # was: GradientBoostingClassifier
model = XGBClassifier(n_estimators=100)
```

---

## Build and publish

```bash
chmod +x build.sh

./build.sh pip                          # build pip wheel + sdist
./build.sh conda                        # build conda package
./build.sh                              # build both

# Publish to private Anaconda repo
export ANACONDA_TOKEN=<your-token>
export ANACONDA_CHANNEL=<your-channel>
UPLOAD=private ./build.sh conda

# Publish to PyPI
UPLOAD=pypi ./build.sh pip
```

---

## Project layout

```
fraud-platform/
├── src/fraud_platform/
│   ├── __init__.py      public API
│   ├── state.py         PipelineState DTO
│   ├── registry.py      @feature_step, @training_step decorators
│   └── engine.py        Dask distributed execution engine
├── examples/
│   ├── fraud_features.py   example DS file (feature + training steps)
│   └── run.py              example entrypoint
├── tests/
│   └── test_pipeline.py    full test suite
├── conda/
│   ├── meta.yaml           conda recipe
│   └── conda_build_config.yaml
├── pyproject.toml          pip packaging config
├── build.sh                build + publish script
└── README.md
```

---

## Python versions

3.10, 3.11, 3.12

---

## License

MIT
