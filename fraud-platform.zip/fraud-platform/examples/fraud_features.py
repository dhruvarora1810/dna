"""
Example fraud feature engineering file.

This is the ONLY file a data scientist needs to write.
No Dask, no distributed computing, no pipeline wiring.

Rules:
    1. Decorate with @feature_step or @training_step
    2. Always copy state.data before modifying: df = state.data.copy()
    3. Always return with: return state.clone_with(data=df)
    4. Use state.metadata to read config (thresholds, lists etc.)
    5. Use state.artifacts to store models after training

Model swap reference (change ONE import line in train_model):
    sklearn:   from sklearn.ensemble import GradientBoostingClassifier
    XGBoost:   from xgboost import XGBClassifier
    LightGBM:  from lightgbm import LGBMClassifier
    CatBoost:  from catboost import CatBoostClassifier
"""

import pandas as pd
from fraud_platform import feature_step, training_step, PipelineState


# ── FEATURE STEPS ─────────────────────────────────────────────────────────────
# Each step adds one or more columns to state.data.
# Steps run in the order they are defined here (top to bottom).
# If step B needs a column from step A, define step A first.


@feature_step
def flag_weekend_transaction(state: PipelineState) -> PipelineState:
    """
    Flag transactions that occur on weekends.
    Fraud rates are approximately 2x higher on weekends.

    Adds column: is_weekend (int, 0 or 1)
    Requires:    timestamp (datetime-like)
    """
    df = state.data.copy()
    df["is_weekend"] = (
        pd.to_datetime(df["timestamp"]).dt.dayofweek.isin([5, 6]).astype(int)
    )
    return state.clone_with(data=df)


@feature_step
def compute_amount_zscore(state: PipelineState) -> PipelineState:
    """
    Z-score of transaction amount relative to the card's history.

    Measures how unusual this amount is for this specific card.
    High z-score (e.g. > 3) = unusually large = elevated fraud risk.

    Adds column: amount_zscore (float)
    Requires:    card_id, amount
    """
    df = state.data.copy()
    grp = df.groupby("card_id")["amount"].transform
    df["amount_zscore"] = (df["amount"] - grp("mean")) / (grp("std") + 1e-6)
    return state.clone_with(data=df)


@feature_step
def flag_high_risk_merchant(state: PipelineState) -> PipelineState:
    """
    Flag transactions at merchant category codes with elevated fraud rates.

    Default high-risk MCCs:
        5912 = Drug stores / pharmacies
        7995 = Gambling
        4829 = Money transfer

    Override the list at runtime without code changes:
        run_feature_pipeline(df, metadata={"risky_mccs": [5912, 7995, 9999]})

    Adds column: is_high_risk_mcc (int, 0 or 1)
    Requires:    merchant_category_code
    """
    df = state.data.copy()
    default_risky = {5912, 7995, 4829}
    risky = set(state.metadata.get("risky_mccs", default_risky))
    df["is_high_risk_mcc"] = df["merchant_category_code"].isin(risky).astype(int)
    return state.clone_with(data=df)


@feature_step
def flag_large_transaction(state: PipelineState) -> PipelineState:
    """
    Flag transactions above a configurable amount threshold.

    Default threshold: $500. Override at runtime:
        run_feature_pipeline(df, metadata={"large_txn_threshold": 300})

    Adds column: is_large_txn (int, 0 or 1)
    Requires:    amount
    """
    df = state.data.copy()
    threshold = state.metadata.get("large_txn_threshold", 500)
    df["is_large_txn"] = (df["amount"] > threshold).astype(int)
    return state.clone_with(data=df)


@feature_step
def compute_velocity(state: PipelineState) -> PipelineState:
    """
    Transaction count per card in the current batch window.

    High velocity (many transactions in a short period) is a
    strong fraud signal, especially for card-present fraud.

    Adds column: card_txn_count (int)
    Requires:    card_id, amount
    """
    df = state.data.copy()
    df["card_txn_count"] = df.groupby("card_id")["amount"].transform("count")
    return state.clone_with(data=df)


# ── TRAINING STEP ─────────────────────────────────────────────────────────────
# Runs on the driver (not distributed) with the full enriched dataset.
# Swap the model class for any sklearn-compatible model — nothing else changes.


@training_step
def train_model(state: PipelineState) -> PipelineState:
    """
    Train a fraud detection model on the engineered features.

    Stores the trained model and feature column list in state.artifacts
    so they can be retrieved after the pipeline completes.

    Stores in artifacts: model, feature_cols
    Stores in metadata:  val_auc

    Requires: all feature columns above + is_fraud label column
    """
    # ── swap this import to change the model ──────────────────────────────────
    from sklearn.ensemble import GradientBoostingClassifier
    # from xgboost import XGBClassifier
    # from lightgbm import LGBMClassifier
    # from catboost import CatBoostClassifier
    # ─────────────────────────────────────────────────────────────────────────
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import roc_auc_score

    FEATURES = [
        "is_weekend",
        "amount_zscore",
        "is_high_risk_mcc",
        "is_large_txn",
        "card_txn_count",
    ]
    LABEL = "is_fraud"

    df = state.data.dropna(subset=FEATURES + [LABEL])
    X, y = df[FEATURES], df[LABEL]

    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )

    # ── swap the model class here ─────────────────────────────────────────────
    model = GradientBoostingClassifier(n_estimators=100, max_depth=3, random_state=42)
    # model = XGBClassifier(n_estimators=100, verbosity=0)
    # model = LGBMClassifier(n_estimators=100, verbose=-1)
    # model = CatBoostClassifier(n_estimators=100, verbose=0)
    # ─────────────────────────────────────────────────────────────────────────

    model.fit(X_train, y_train)
    val_auc = roc_auc_score(y_val, model.predict_proba(X_val)[:, 1])
    print(f"[train_model] Validation AUC: {val_auc:.4f}")

    return state.clone_with(
        artifacts={"model": model, "feature_cols": FEATURES},
        metadata={"val_auc": round(val_auc, 4)},
    )
