"""
Example pipeline entrypoint.

Local:
    cd examples
    python run.py               # 200k rows
    python run.py 1000000       # 1M rows

OpenShift (no code change — just set the env var):
    export DASK_SCHEDULER_ADDRESS=tcp://<scheduler-ip>:8786
    python run.py
"""

import sys
import numpy as np
import pandas as pd

# This import registers all @feature_step and @training_step functions.
# It must happen before run_feature_pipeline() is called.
import fraud_features  # noqa: F401

from fraud_platform import run_feature_pipeline, run_training_pipeline
from fraud_platform.registry import get_feature_steps, get_training_steps


def make_fake_transactions(n: int = 200_000) -> pd.DataFrame:
    """Generate synthetic transaction data for testing."""
    np.random.seed(42)
    return pd.DataFrame({
        "card_id": np.random.choice([f"card_{i}" for i in range(500)], n),
        "timestamp": pd.date_range("2024-01-01", periods=n, freq="1s"),
        "amount": np.random.exponential(scale=80, size=n).round(2),
        "merchant_category_code": np.random.choice([5912, 7995, 5411, 4829, 5999], n),
        "is_fraud": np.random.binomial(1, 0.02, n),
    })


if __name__ == "__main__":
    n_rows = int(sys.argv[1]) if len(sys.argv) > 1 else 200_000

    print(f"\nGenerating {n_rows:,} transactions...")
    df = make_fake_transactions(n_rows)
    print(f"Input shape  : {df.shape}")
    print(f"Columns      : {df.columns.tolist()}")

    # ── Feature engineering ──────────────────────────────────────────────────
    print("\nRunning feature pipeline (Dask distributed)...")
    feature_state = run_feature_pipeline(
        df=df,
        steps=get_feature_steps(),
        metadata={
            "large_txn_threshold": 300,
            "risky_mccs": [5912, 7995, 4829],
        },
    )
    new_cols = [c for c in feature_state.data.columns if c not in df.columns]
    print(f"Output shape : {feature_state.data.shape}")
    print(f"New features : {new_cols}")
    print(feature_state.data[new_cols].describe().round(3).to_string())

    # ── Model training ───────────────────────────────────────────────────────
    print("\nRunning training pipeline...")
    final_state = run_training_pipeline(
        state=feature_state,
        steps=get_training_steps(),
    )

    print(f"\nValidation AUC : {final_state.metadata['val_auc']}")
    print(f"Model type     : {type(final_state.artifacts['model']).__name__}")
    print(f"Feature cols   : {final_state.artifacts['feature_cols']}")
    print("\n✓ Pipeline complete")
