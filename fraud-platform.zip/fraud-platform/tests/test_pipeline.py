"""
Test suite for fraud-platform.

Run with:
    pytest tests/ -v
    pytest tests/ -v --cov=fraud_platform

Tests use Dask's local scheduler — no cluster needed.
"""

import pandas as pd
import numpy as np
import pytest
from fraud_platform import feature_step, training_step, PipelineState
from fraud_platform import run_feature_pipeline, run_training_pipeline
from fraud_platform.registry import _FEATURE_STEPS, _TRAINING_STEPS


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def clear_registry():
    """
    Clear the step registry before and after every test.
    Prevents steps registered in one test from affecting another.
    """
    _FEATURE_STEPS.clear()
    _TRAINING_STEPS.clear()
    yield
    _FEATURE_STEPS.clear()
    _TRAINING_STEPS.clear()


def make_df(n: int = 2_000) -> pd.DataFrame:
    """Minimal transaction DataFrame for testing."""
    np.random.seed(42)
    return pd.DataFrame({
        "card_id": np.random.choice(["A", "B", "C"], n),
        "amount": np.random.exponential(50, n).round(2),
        "timestamp": pd.date_range("2024-01-01", periods=n, freq="1s"),
        "merchant_category_code": np.random.choice([5912, 7995, 5411], n),
        "is_fraud": np.random.binomial(1, 0.02, n),
    })


# ── PipelineState tests ───────────────────────────────────────────────────────

class TestPipelineState:

    def test_clone_with_replaces_data(self):
        df1 = pd.DataFrame({"a": [1, 2]})
        df2 = pd.DataFrame({"a": [3, 4]})
        state = PipelineState(data=df1)
        new_state = state.clone_with(data=df2)
        pd.testing.assert_frame_equal(new_state.data, df2)

    def test_clone_with_preserves_original(self):
        df = pd.DataFrame({"a": [1]})
        state = PipelineState(data=df)
        state.clone_with(data=pd.DataFrame({"a": [99]}))
        pd.testing.assert_frame_equal(state.data, df)  # original unchanged

    def test_clone_with_merges_metadata(self):
        state = PipelineState(data=pd.DataFrame(), metadata={"a": 1, "b": 2})
        new_state = state.clone_with(metadata={"b": 99, "c": 3})
        assert new_state.metadata == {"a": 1, "b": 99, "c": 3}

    def test_clone_with_merges_artifacts(self):
        state = PipelineState(data=pd.DataFrame(), artifacts={"model": "old"})
        new_state = state.clone_with(artifacts={"model": "new", "scaler": "s"})
        assert new_state.artifacts == {"model": "new", "scaler": "s"}

    def test_defaults_are_empty(self):
        state = PipelineState(data=pd.DataFrame())
        assert state.metadata == {}
        assert state.artifacts == {}


# ── Feature step tests ────────────────────────────────────────────────────────

class TestFeatureSteps:

    def test_step_adds_column(self):
        @feature_step
        def add_flag(state: PipelineState) -> PipelineState:
            df = state.data.copy()
            df["flag"] = 1
            return state.clone_with(data=df)

        result = run_feature_pipeline(make_df())
        assert "flag" in result.data.columns
        assert result.data["flag"].eq(1).all()

    def test_row_count_preserved(self):
        @feature_step
        def identity(state: PipelineState) -> PipelineState:
            return state

        df = make_df(500)
        result = run_feature_pipeline(df)
        assert len(result.data) == 500

    def test_step_order_preserved(self):
        order = []

        @feature_step
        def step_a(state: PipelineState) -> PipelineState:
            order.append("a")
            return state

        @feature_step
        def step_b(state: PipelineState) -> PipelineState:
            order.append("b")
            return state

        run_feature_pipeline(make_df())
        assert order == ["a", "b"]

    def test_multiple_steps_accumulate_columns(self):
        @feature_step
        def add_x(state: PipelineState) -> PipelineState:
            df = state.data.copy()
            df["x"] = 1
            return state.clone_with(data=df)

        @feature_step
        def add_y(state: PipelineState) -> PipelineState:
            df = state.data.copy()
            df["y"] = 2
            return state.clone_with(data=df)

        result = run_feature_pipeline(make_df())
        assert "x" in result.data.columns
        assert "y" in result.data.columns

    def test_metadata_flows_to_steps(self):
        @feature_step
        def use_threshold(state: PipelineState) -> PipelineState:
            df = state.data.copy()
            t = state.metadata["threshold"]
            df["high"] = (df["amount"] > t).astype(int)
            return state.clone_with(data=df)

        result = run_feature_pipeline(make_df(), metadata={"threshold": 100})
        assert "high" in result.data.columns

    def test_metadata_default_used_when_key_missing(self):
        @feature_step
        def use_threshold(state: PipelineState) -> PipelineState:
            df = state.data.copy()
            t = state.metadata.get("threshold", 999999)
            df["high"] = (df["amount"] > t).astype(int)
            return state.clone_with(data=df)

        result = run_feature_pipeline(make_df())  # no metadata passed
        assert result.data["high"].sum() == 0  # threshold so high = nothing flagged

    def test_no_steps_raises_helpful_error(self):
        with pytest.raises(RuntimeError, match="No feature steps registered"):
            run_feature_pipeline(make_df(), steps=[])

    def test_override_steps_with_explicit_list(self):
        """Steps= override should bypass the registry."""
        @feature_step
        def registered_step(state: PipelineState) -> PipelineState:
            df = state.data.copy()
            df["from_registry"] = 1
            return state.clone_with(data=df)

        def unregistered_step(state: PipelineState) -> PipelineState:
            df = state.data.copy()
            df["from_override"] = 1
            return state.clone_with(data=df)

        result = run_feature_pipeline(make_df(), steps=[unregistered_step])
        assert "from_override" in result.data.columns
        assert "from_registry" not in result.data.columns


# ── Training step tests ───────────────────────────────────────────────────────

class TestTrainingSteps:

    def test_training_step_stores_artifact(self):
        @training_step
        def store_model(state: PipelineState) -> PipelineState:
            return state.clone_with(artifacts={"model": "fake_model"})

        df = make_df()
        feature_state = run_feature_pipeline(df, steps=[lambda s: s])  # identity

        # Manually re-register after clear — training step needs to be in the list
        _TRAINING_STEPS.append(store_model)
        final = run_training_pipeline(feature_state)
        assert final.artifacts["model"] == "fake_model"

    def test_training_step_stores_metadata(self):
        @training_step
        def record_metric(state: PipelineState) -> PipelineState:
            return state.clone_with(metadata={"val_auc": 0.85})

        state = PipelineState(data=make_df())
        final = run_training_pipeline(state, steps=[record_metric])
        assert final.metadata["val_auc"] == 0.85

    def test_training_receives_feature_output(self):
        """Training step should see columns added by feature steps."""
        @feature_step
        def add_col(state: PipelineState) -> PipelineState:
            df = state.data.copy()
            df["engineered"] = 42
            return state.clone_with(data=df)

        seen_cols = []

        @training_step
        def check_cols(state: PipelineState) -> PipelineState:
            seen_cols.extend(state.data.columns.tolist())
            return state

        feature_state = run_feature_pipeline(make_df())
        run_training_pipeline(feature_state, steps=[check_cols])
        assert "engineered" in seen_cols


# ── End-to-end test ───────────────────────────────────────────────────────────

class TestEndToEnd:

    def test_full_pipeline_with_real_features(self):
        """Smoke test: imports example features and runs full pipeline."""
        import sys
        import os
        # Add examples/ to path so we can import fraud_features
        examples_dir = os.path.join(os.path.dirname(__file__), "..", "examples")
        sys.path.insert(0, os.path.abspath(examples_dir))

        # Clear any previously imported module to re-trigger registration
        if "fraud_features" in sys.modules:
            del sys.modules["fraud_features"]
        _FEATURE_STEPS.clear()
        _TRAINING_STEPS.clear()

        import fraud_features  # noqa: F401
        from fraud_platform.registry import get_feature_steps, get_training_steps

        df = make_df(2_000)
        feature_state = run_feature_pipeline(
            df,
            steps=get_feature_steps(),
            metadata={"large_txn_threshold": 100, "risky_mccs": [5912]},
        )

        expected_cols = [
            "is_weekend", "amount_zscore",
            "is_high_risk_mcc", "is_large_txn", "card_txn_count",
        ]
        for col in expected_cols:
            assert col in feature_state.data.columns, f"Missing column: {col}"

        assert len(feature_state.data) == len(df)

        final_state = run_training_pipeline(
            feature_state,
            steps=get_training_steps(),
        )
        assert "model" in final_state.artifacts
        assert "val_auc" in final_state.metadata
        assert 0.0 <= final_state.metadata["val_auc"] <= 1.0
