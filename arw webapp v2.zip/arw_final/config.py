# ═══════════════════════════════════════════════════════════════════════
#  config.py  —  Edit the values marked  ← CHANGE THIS
#  Everything else can stay as-is for the POC.
# ═══════════════════════════════════════════════════════════════════════

# ── Tables analysts can build features against ───────────────────────────
# Format: ("Display label", "hive_catalog.schema.table", "entity_col", "partition_col")
# Add or remove rows to control what shows in the dropdown.
AVAILABLE_TABLES = [
    ("FRH_CCCA — Branded Cards Auth",  "hive.fraud.frh_ccca_vw",   "account_id",  "event_date"),
    ("FRH_CRS  — Retail Auth",         "hive.fraud.frh_crs_vw",    "account_id",  "event_date"),
    ("FRH_IBS  — IBS Auth",            "hive.fraud.frh_ibs_vw",    "account_id",  "txn_date"),
    ("FRH_MERCH — Merchant Feed",      "hive.fraud.frh_merch_vw",  "merchant_id", "load_date"),
]

# ── Starburst / Trino  (form-builder previews — fast, ad-hoc) ────────────
# Used for: preview queries when analyst clicks "Run on latest partition"
# in Form Builder mode. Returns results in seconds using your existing
# 107-worker cluster — no Spark startup delay.

STARBURST_HOST       = "your-starburst-coordinator.citi.com"   # ← CHANGE THIS
STARBURST_PORT       = 443                                      # ← CHANGE THIS (8080 if http)
STARBURST_USER       = "arw_service"                           # ← CHANGE THIS
STARBURST_HTTP_SCHEME = "https"                                 # "http" if no TLS internally

# Auth method: "kerberos" | "basic" | "none"
STARBURST_AUTH       = "kerberos"                               # ← CHANGE THIS
STARBURST_PASSWORD   = ""                  # only fill in if STARBURST_AUTH = "basic"

# Trino session properties — routes preview queries to your ad-hoc pool
STARBURST_SESSION_PROPS = {
    "query_max_execution_time": "5m",
}

# ── Spark  (code-editor previews + future production tile builds) ─────────
# Spark is only initialized the FIRST time someone uses the Code Editor tab.
# Form Builder uses Starburst instead, so the app starts in seconds.

SPARK_APP_NAME      = "ARW-FeatureBuilder"
SPARK_EXECUTOR_MEM  = "4g"
SPARK_DRIVER_MEM    = "2g"

# ── App ───────────────────────────────────────────────────────────────────
REGISTRY_DB   = "/shared/arw/feature_registry.db"  # ← CHANGE THIS to a shared path
HOST          = "0.0.0.0"
PORT          = 8050
PREVIEW_LIMIT = 50
