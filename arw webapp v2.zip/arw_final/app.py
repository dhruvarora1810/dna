"""
app.py  —  ARW Feature Builder
===============================
Form Builder  → Starburst/Trino  (fast preview, seconds, no Spark startup)
Code Editor   → Spark            (arbitrary PySpark, lazy-initialized on first use)

Start: bash start.sh
"""
import json, sqlite3, threading, traceback, uuid, textwrap
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, jsonify, render_template, request

import config

app = Flask(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
#  STARBURST / TRINO  (form builder previews)
# ═══════════════════════════════════════════════════════════════════════════════
import trino
import trino.auth
import pandas as pd


def _trino_conn() -> trino.dbapi.Connection:
    """Open a Trino connection using the configured auth method."""
    auth = None
    if config.STARBURST_AUTH == "kerberos":
        auth = trino.auth.KerberosAuthentication()
    elif config.STARBURST_AUTH == "basic":
        auth = trino.auth.BasicAuthentication(config.STARBURST_USER, config.STARBURST_PASSWORD)

    return trino.dbapi.connect(
        host        = config.STARBURST_HOST,
        port        = config.STARBURST_PORT,
        user        = config.STARBURST_USER,
        http_scheme = config.STARBURST_HTTP_SCHEME,
        auth        = auth,
        session_properties = config.STARBURST_SESSION_PROPS,
    )


def _get_partitions_trino(hive_table: str, partition_col: str) -> list[str]:
    """Return sorted list of distinct partition values via Starburst."""
    sql  = f"SELECT DISTINCT {partition_col} FROM {hive_table} ORDER BY {partition_col}"
    conn = _trino_conn()
    cur  = conn.cursor()
    cur.execute(sql)
    return [str(r[0]) for r in cur.fetchall()]


def _run_form_job(spec: dict) -> dict:
    """
    Run a form-defined velocity feature via Starburst.
    Returns preview rows + the generated SQL so the analyst can see what ran.
    """
    hive_table, entity_col, partition_col = _resolve_table(spec["source_table"])
    n     = int(spec["window_days"])
    name  = spec["name"]
    filt  = (spec.get("filter_expr") or "").strip()
    agg   = spec["aggregation"]
    field = (spec.get("agg_field") or "").strip() or None

    # last N partition values
    parts  = _get_partitions_trino(hive_table, partition_col)
    window = parts[-n:] if len(parts) >= n else parts
    if not window:
        raise RuntimeError(f"No partitions found in {hive_table}")
    latest = window[-1]
    quoted = ", ".join(f"'{p}'" for p in window)

    agg_expr = {
        "count":          "COUNT(*)",
        "sum":            f"SUM({field})",
        "avg":            f"AVG({field})",
        "min":            f"MIN({field})",
        "max":            f"MAX({field})",
        "count_distinct": f"COUNT(DISTINCT {field})",
    }.get(agg)
    if agg_expr is None:
        raise ValueError(f"Unknown aggregation: {agg}")

    where_clauses = [f"{partition_col} IN ({quoted})"]
    if filt:
        where_clauses.append(f"({filt})")
    where = "\n      AND ".join(where_clauses)

    sql = textwrap.dedent(f"""
        SELECT {entity_col},
               {agg_expr} AS {name}
        FROM   {hive_table}
        WHERE  {where}
        GROUP BY {entity_col}
        ORDER BY {name} DESC
        LIMIT  {config.PREVIEW_LIMIT}
    """).strip()

    conn = _trino_conn()
    cur  = conn.cursor()
    cur.execute(sql)
    rows  = cur.fetchall()
    cols  = [d[0] for d in cur.description]
    pdf   = pd.DataFrame(rows, columns=cols)

    return {
        "columns": list(pdf.columns),
        "rows":    pdf.values.tolist(),
        "latest":  latest,
        "n_parts": len(window),
        "count":   len(pdf),
        "sql":     sql,
        "engine":  "starburst",
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  SPARK  (code editor — lazy initialized on first use)
# ═══════════════════════════════════════════════════════════════════════════════
_spark = None
_spark_lock = threading.Lock()


def _get_spark():
    """Return the SparkSession, initializing it on first call."""
    global _spark
    if _spark is None:
        with _spark_lock:
            if _spark is None:
                from pyspark.sql import SparkSession
                print("⏳  Initialising Spark (first code editor run) …")
                _spark = (SparkSession.builder
                          .appName(config.SPARK_APP_NAME)
                          .config("spark.executor.memory", config.SPARK_EXECUTOR_MEM)
                          .config("spark.driver.memory",   config.SPARK_DRIVER_MEM)
                          .config("spark.sql.catalogImplementation", "hive")
                          .enableHiveSupport()
                          .getOrCreate())
                print(f"✅  Spark {_spark.version} ready")
    return _spark


def _get_partitions_spark(hive_table: str, partition_col: str) -> list[str]:
    spark = _get_spark()
    rows  = spark.sql(f"SHOW PARTITIONS {hive_table}").collect()
    return sorted([r[0].split("=")[-1].strip() for r in rows])


def _load_window_spark(hive_table: str, partition_col: str, n_days: int):
    parts  = _get_partitions_spark(hive_table, partition_col)
    window = parts[-n_days:] if len(parts) >= n_days else parts
    latest = window[-1]
    quoted = ", ".join(f"'{p}'" for p in window)
    df     = _get_spark().sql(
        f"SELECT * FROM {hive_table} WHERE {partition_col} IN ({quoted})"
    )
    return df, latest, len(window)


def _run_code_job(code_str: str, hive_table: str, n_days: int) -> dict:
    """
    Run user-written PySpark code via Spark.
    The framework loads the data; the user writes the transformation.
    """
    import pyspark.sql.functions as F  # noqa — available after Spark init

    hive_table, entity_col, partition_col = _resolve_table(hive_table)
    df, latest, n_parts = _load_window_spark(hive_table, partition_col, n_days)

    ns = {}
    exec(compile(code_str, "<feature_editor>", "exec"), ns)
    if "compute_feature" not in ns:
        raise ValueError("Code must define:  def compute_feature(df, entity_col)")

    result = ns["compute_feature"](df, entity_col).limit(config.PREVIEW_LIMIT)
    pdf    = result.toPandas()
    return {
        "columns": list(pdf.columns),
        "rows":    pdf.values.tolist(),
        "latest":  latest,
        "n_parts": n_parts,
        "count":   len(pdf),
        "sql":     None,
        "engine":  "spark",
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  SHARED HELPERS
# ═══════════════════════════════════════════════════════════════════════════════
def _table_map() -> dict:
    return {
        t: {"label": lbl, "entity_col": ec, "partition_col": pc}
        for lbl, t, ec, pc in config.AVAILABLE_TABLES
    }


def _resolve_table(hive_table: str) -> tuple[str, str, str]:
    tm = _table_map()
    if hive_table not in tm:
        raise ValueError(f"Table '{hive_table}' is not in the allowed list")
    m = tm[hive_table]
    return hive_table, m["entity_col"], m["partition_col"]


# ── Registry (SQLite) ─────────────────────────────────────────────────────────
def _reg():
    Path(config.REGISTRY_DB).parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(config.REGISTRY_DB)
    con.row_factory = sqlite3.Row
    con.executescript("""
        CREATE TABLE IF NOT EXISTS feature (
            name         TEXT PRIMARY KEY,
            source_table TEXT,
            mode         TEXT,
            spec_json    TEXT,
            code_body    TEXT,
            owner        TEXT,
            status       TEXT DEFAULT 'pending',
            submitted_at TEXT
        );
        CREATE TABLE IF NOT EXISTS audit (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            feature_name TEXT,
            action       TEXT,
            actor        TEXT,
            note         TEXT,
            ts           TEXT
        );
    """)
    con.commit()
    return con


def _ts() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ── Background job tracker ─────────────────────────────────────────────────────
_jobs: dict[str, dict] = {}


def _run_in_thread(job_id: str, fn, *args):
    def _worker():
        try:
            _jobs[job_id] = {"status": "done", "result": fn(*args)}
        except Exception as e:
            _jobs[job_id] = {
                "status":  "error",
                "error":   traceback.format_exc(limit=8),
                "message": str(e),
            }
    _jobs[job_id] = {"status": "running"}
    threading.Thread(target=_worker, daemon=True).start()


# ═══════════════════════════════════════════════════════════════════════════════
#  FLASK ROUTES
# ═══════════════════════════════════════════════════════════════════════════════
@app.route("/")
def index():
    tables = [
        {"label": lbl, "table": t, "entity": ec, "partition": pc}
        for lbl, t, ec, pc in config.AVAILABLE_TABLES
    ]
    return render_template("index.html", tables=json.dumps(tables))


@app.route("/api/tables")
def api_tables():
    return jsonify([
        {"label": lbl, "table": t, "entity_col": ec, "partition_col": pc}
        for lbl, t, ec, pc in config.AVAILABLE_TABLES
    ])


@app.route("/api/info")
def api_info():
    hive_table = request.args.get("table", "")
    try:
        hive_table, entity_col, partition_col = _resolve_table(hive_table)
        parts = _get_partitions_trino(hive_table, partition_col)
        return jsonify({
            "latest":        parts[-1] if parts else None,
            "partition_col": partition_col,
            "entity_col":    entity_col,
            "table":         hive_table,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/run/form", methods=["POST"])
def api_run_form():
    spec = request.json
    for k in ["name", "aggregation", "window_days", "owner", "source_table"]:
        if not spec.get(k):
            return jsonify({"error": f"'{k}' is required"}), 400
    if " " in spec["name"]:
        return jsonify({"error": "Feature name must have no spaces"}), 400
    if spec["source_table"] not in _table_map():
        return jsonify({"error": "Table not in allowed list"}), 400

    job_id = str(uuid.uuid4())[:8]
    _run_in_thread(job_id, _run_form_job, spec)
    return jsonify({"job_id": job_id})


@app.route("/api/run/code", methods=["POST"])
def api_run_code():
    body  = request.json
    name  = (body.get("name") or "").strip()
    owner = (body.get("owner") or "").strip()
    table = (body.get("source_table") or "").strip()
    code  = body.get("code", "")
    n     = int(body.get("window_days", 30))

    if not name or " " in name:
        return jsonify({"error": "Feature name must be non-empty with no spaces"}), 400
    if not owner:
        return jsonify({"error": "Owner is required"}), 400
    if not table or table not in _table_map():
        return jsonify({"error": "Table not in allowed list"}), 400
    if "compute_feature" not in code:
        return jsonify({"error": "Code must define:  def compute_feature(df, entity_col)"}), 400

    job_id = str(uuid.uuid4())[:8]
    _run_in_thread(job_id, _run_code_job, code, table, n)
    return jsonify({"job_id": job_id})


@app.route("/api/job/<job_id>")
def api_job_status(job_id):
    job = _jobs.get(job_id)
    if not job:
        return jsonify({"status": "unknown"}), 404
    return jsonify(job)


@app.route("/api/submit", methods=["POST"])
def api_submit():
    body  = request.json
    name  = (body.get("name") or "").strip()
    owner = (body.get("owner") or "").strip()
    table = body.get("source_table", "")
    mode  = body.get("mode", "form")

    if not name or not owner:
        return jsonify({"error": "name and owner are required"}), 400

    con = _reg()
    ts  = _ts()
    con.execute("""
        INSERT INTO feature
            (name, source_table, mode, spec_json, code_body, owner, status, submitted_at)
        VALUES (?,?,?,?,?,?,'pending',?)
        ON CONFLICT(name) DO UPDATE SET
            source_table = excluded.source_table,
            mode         = excluded.mode,
            spec_json    = excluded.spec_json,
            code_body    = excluded.code_body,
            owner        = excluded.owner,
            status       = 'pending',
            submitted_at = excluded.submitted_at
    """, (
        name, table, mode,
        json.dumps(body.get("spec")) if body.get("spec") else None,
        body.get("code"),
        owner, ts,
    ))
    con.execute(
        "INSERT INTO audit (feature_name,action,actor,note,ts) VALUES (?,?,?,?,?)",
        (name, "submit", owner, f"mode={mode} table={table}", ts),
    )
    con.commit()
    con.close()
    return jsonify({"ok": True, "name": name, "status": "pending", "submitted_at": ts})


@app.route("/api/queue")
def api_queue():
    con  = _reg()
    rows = con.execute(
        "SELECT name, source_table, mode, owner, status, submitted_at "
        "FROM feature ORDER BY submitted_at DESC"
    ).fetchall()
    con.close()
    return jsonify([dict(r) for r in rows])


# ── Start ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print(f"\n🛡️  ARW Feature Builder")
    print(f"   Form previews : Starburst ({config.STARBURST_HOST})")
    print(f"   Code editor   : Spark (lazy — initializes on first code run)")
    print(f"   Tables        : {len(config.AVAILABLE_TABLES)} configured")
    print(f"   Access        : http://<edge-node-hostname>:{config.PORT}\n")
    app.run(host=config.HOST, port=config.PORT, threaded=True)
