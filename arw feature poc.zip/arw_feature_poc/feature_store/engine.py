"""
The generic materialization engine.

This is the ONE piece of compute. It reads a FeatureSpec and produces the
feature values. In production this is a Spark job writing Iceberg; in the POC
it's pandas writing CSV. The logic — point-in-time-correct windowed aggregation
— is identical. You never write a new engine per feature; you write a spec.

Point-in-time correctness: for each (entity, event row) we aggregate ONLY the
rows in the trailing window that occurred STRICTLY BEFORE that row's timestamp
(closed='left'). That is what prevents label leakage when these features feed a
model or a rule.
"""
from __future__ import annotations

import pandas as pd
from .spec import FeatureSpec


def _agg_series(values: pd.Series, aggregation: str) -> float:
    if aggregation == "count":
        return float(values.shape[0])
    if aggregation == "sum":
        return float(values.sum())
    if aggregation == "avg":
        return float(values.mean()) if len(values) else 0.0
    if aggregation == "min":
        return float(values.min()) if len(values) else 0.0
    if aggregation == "max":
        return float(values.max()) if len(values) else 0.0
    if aggregation == "count_distinct":
        return float(values.nunique())
    raise ValueError(f"unsupported aggregation {aggregation}")


def materialize(spec: FeatureSpec, source_df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute the velocity feature defined by `spec` over `source_df`.

    Returns a tidy frame: [entity, timestamp_col, <spec.name>]
    one value per source row, computed as-of that row (no leakage).
    """
    spec.validate()
    df = source_df.copy()
    df[spec.timestamp_col] = pd.to_datetime(df[spec.timestamp_col])

    # 1) apply the optional filter (e.g. only DENY rows for a denials feature)
    if spec.filter_expr:
        df = df.query(spec.filter_expr)

    # the column we aggregate; for plain count we count rows via the entity
    # column (which survives set_index on the timestamp below)
    value_col = spec.agg_field if spec.agg_field else spec.entity

    # 2) per-entity, trailing time-window aggregation, EXCLUDING the current row
    window = f"{spec.window_days}D"
    out_frames = []

    for entity_val, g in df.sort_values(spec.timestamp_col).groupby(spec.entity):
        g = g.set_index(spec.timestamp_col)
        roll = g[value_col].rolling(window, closed="left")
        if spec.aggregation == "count":
            feat = roll.count()
        elif spec.aggregation == "sum":
            feat = roll.sum()
        elif spec.aggregation == "avg":
            feat = roll.mean()
        elif spec.aggregation == "min":
            feat = roll.min()
        elif spec.aggregation == "max":
            feat = roll.max()
        elif spec.aggregation == "count_distinct":
            # rolling nunique isn't built in; apply over the window
            feat = roll.apply(lambda s: s.nunique(), raw=False)
        else:
            raise ValueError(spec.aggregation)

        res = feat.reset_index()
        res.columns = [spec.timestamp_col, spec.name]
        res[spec.entity] = entity_val
        out_frames.append(res)

    result = pd.concat(out_frames, ignore_index=True)
    result[spec.name] = result[spec.name].fillna(0)
    if spec.data_type == "int":
        result[spec.name] = result[spec.name].astype(int)

    # NOTE: when a filter is applied, rows are only produced for entities that
    # have at least one matching row. For a feature like denials_30d this is
    # expected — accounts with zero denials simply have no denial events to
    # anchor on. When joined to the full population (Template A in the serving
    # layer), missing -> 0.
    return result[[spec.entity, spec.timestamp_col, spec.name]].sort_values(
        [spec.entity, spec.timestamp_col]
    ).reset_index(drop=True)


def preview(spec: FeatureSpec, source_df: pd.DataFrame, n: int = 10) -> pd.DataFrame:
    """Quick sample + simple distribution, for the 'preview before submit' step."""
    feats = materialize(spec, source_df)
    print(f"Feature '{spec.name}'  ({spec.aggregation}"
          + (f" of {spec.agg_field}" if spec.agg_field else "")
          + f", {spec.window_days}d"
          + (f", where {spec.filter_expr}" if spec.filter_expr else "") + ")")
    print(f"rows produced: {len(feats):,}")
    desc = feats[spec.name].describe()
    print(desc.to_string())
    return feats.head(n)
