"""
Feature registry + governance workflow (SQLite for the POC; Postgres in prod).

Stores DEFINITIONS and STATUS, never feature data. Implements the approval gate:
    draft/in_review  --approve-->  production  (only then can it materialize)
Every transition is written to an audit log.
"""
from __future__ import annotations

import sqlite3
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from .spec import FeatureSpec

DB_PATH = Path(__file__).parent.parent / "registry.db"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect(db_path: Path = DB_PATH) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(db_path: Path = DB_PATH) -> None:
    conn = connect(db_path)
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS feature (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            name          TEXT UNIQUE NOT NULL,
            entity        TEXT NOT NULL,
            spec_json     TEXT NOT NULL,
            data_type     TEXT NOT NULL,
            owner         TEXT NOT NULL,
            status        TEXT NOT NULL DEFAULT 'in_review',  -- in_review|production|deprecated
            version       INTEGER NOT NULL DEFAULT 1,
            created_at    TEXT NOT NULL,
            updated_at    TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS approval (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            feature_name  TEXT NOT NULL,
            from_status   TEXT NOT NULL,
            to_status     TEXT NOT NULL,
            actor         TEXT NOT NULL,
            note          TEXT,
            created_at    TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS audit_log (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            feature_name  TEXT NOT NULL,
            action        TEXT NOT NULL,
            actor         TEXT NOT NULL,
            detail        TEXT,
            created_at    TEXT NOT NULL
        );
        """
    )
    conn.commit()
    conn.close()


def _audit(conn, feature_name, action, actor, detail=""):
    conn.execute(
        "INSERT INTO audit_log (feature_name, action, actor, detail, created_at) VALUES (?,?,?,?,?)",
        (feature_name, action, actor, detail, _now()),
    )


# ---------------- core workflow ----------------

def submit_feature(spec: FeatureSpec, actor: str, db_path: Path = DB_PATH) -> None:
    """Door 1 (UI) and Door 2 (notebook) both land here: register as 'in_review'."""
    spec.validate()
    conn = connect(db_path)
    existing = conn.execute("SELECT version FROM feature WHERE name=?", (spec.name,)).fetchone()
    version = (existing["version"] + 1) if existing else 1
    if existing:
        conn.execute(
            "UPDATE feature SET spec_json=?, data_type=?, owner=?, status='in_review', "
            "version=?, updated_at=? WHERE name=?",
            (json.dumps(spec.to_dict()), spec.data_type, spec.owner, version, _now(), spec.name),
        )
    else:
        conn.execute(
            "INSERT INTO feature (name, entity, spec_json, data_type, owner, status, version, created_at, updated_at) "
            "VALUES (?,?,?,?,?,'in_review',1,?,?)",
            (spec.name, spec.entity, json.dumps(spec.to_dict()), spec.data_type, spec.owner, _now(), _now()),
        )
    _audit(conn, spec.name, "submit", actor, f"version={version}")
    conn.commit()
    conn.close()


def approve_feature(name: str, approver: str, note: str = "", db_path: Path = DB_PATH) -> None:
    """The governance gate. Only a supervisor moves a feature to 'production'."""
    conn = connect(db_path)
    row = conn.execute("SELECT status FROM feature WHERE name=?", (name,)).fetchone()
    if not row:
        conn.close()
        raise ValueError(f"feature '{name}' not found")
    from_status = row["status"]
    conn.execute("UPDATE feature SET status='production', updated_at=? WHERE name=?", (_now(), name))
    conn.execute(
        "INSERT INTO approval (feature_name, from_status, to_status, actor, note, created_at) VALUES (?,?,?,?,?,?)",
        (name, from_status, "production", approver, note, _now()),
    )
    _audit(conn, name, "approve", approver, note)
    conn.commit()
    conn.close()


def list_features(status: Optional[str] = None, db_path: Path = DB_PATH):
    conn = connect(db_path)
    if status:
        rows = conn.execute("SELECT * FROM feature WHERE status=? ORDER BY name", (status,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM feature ORDER BY name").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_spec(name: str, db_path: Path = DB_PATH) -> FeatureSpec:
    conn = connect(db_path)
    row = conn.execute("SELECT spec_json FROM feature WHERE name=?", (name,)).fetchone()
    conn.close()
    if not row:
        raise ValueError(f"feature '{name}' not found")
    return FeatureSpec.from_dict(json.loads(row["spec_json"]))


def audit_trail(name: Optional[str] = None, db_path: Path = DB_PATH):
    conn = connect(db_path)
    if name:
        rows = conn.execute("SELECT * FROM audit_log WHERE feature_name=? ORDER BY id", (name,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM audit_log ORDER BY id").fetchall()
    conn.close()
    return [dict(r) for r in rows]
