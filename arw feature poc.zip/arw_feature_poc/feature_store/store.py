"""
Materialization-to-store + serving.

- materialize_to_store: only PRODUCTION features may be written (governance gate
  enforced at compute time). Writes CSV here; Iceberg in prod.
- build_training_set: point-in-time-correct assembly of several features onto a
  label spine — the thing ARW / an ML model actually consumes.
"""
from __future__ import annotations

from pathlib import Path
import pandas as pd

from . import engine, registry
from .spec import FeatureSpec

STORE_DIR = Path(__file__).parent.parent / "feature_tables"


def materialize_to_store(name: str, source_df: pd.DataFrame, db_path: Path = registry.DB_PATH) -> Path:
    """Compute a PRODUCTION feature and persist it. Refuses anything not approved."""
    feats = registry.list_features(db_path=db_path)
    rec = next((f for f in feats if f["name"] == name), None)
    if rec is None:
        raise ValueError(f"feature '{name}' is not registered")
    if rec["status"] != "production":
        raise PermissionError(
            f"feature '{name}' is '{rec['status']}', not 'production' — "
            f"it must be approved before it can be materialized"
        )
    spec = registry.get_spec(name, db_path=db_path)
    result = engine.materialize(spec, source_df)
    STORE_DIR.mkdir(exist_ok=True)
    out = STORE_DIR / f"{name}.csv"
    result.to_csv(out, index=False)
    return out


def build_training_set(spine: pd.DataFrame, feature_names: list[str],
                       entity: str = "account_id", ts_col: str = "txn_ts") -> pd.DataFrame:
    """
    Point-in-time join: for each spine row (entity, event time, label), attach the
    most recent value of each feature at-or-before the event time. No leakage.

    `spine` must have [entity, ts_col, ...label...]. Features are read from the store.
    """
    spine = spine.copy()
    spine[ts_col] = pd.to_datetime(spine[ts_col])
    spine = spine.sort_values(ts_col)
    out = spine

    for name in feature_names:
        path = STORE_DIR / f"{name}.csv"
        if not path.exists():
            raise FileNotFoundError(f"{name} not materialized — run materialize_to_store first")
        feat = pd.read_csv(path)
        feat[ts_col] = pd.to_datetime(feat[ts_col])
        feat = feat.sort_values(ts_col)
        # as-of merge per entity: latest feature value at/before the spine timestamp
        out = pd.merge_asof(
            out.sort_values(ts_col),
            feat[[entity, ts_col, name]].sort_values(ts_col),
            on=ts_col, by=entity, direction="backward",
        )
        # for velocity count/sum features, "no prior events" == 0
        out[name] = out[name].fillna(0)
    return out.reset_index(drop=True)
