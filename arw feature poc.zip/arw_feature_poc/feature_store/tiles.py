"""
Tile builder — the scalable data approach.

Instead of recomputing each window feature from raw authorization records
(a near-full scan per feature, per run), we scan the source ONCE into
fine-grained **daily per-entity partial aggregates** ("tiles"). Every window
feature then becomes a cheap roll-up (sum / min / max / union) over tiles.

  raw auths  --(one scan)-->  account_daily_tiles  --(cheap rollup)-->  denials_30d
                                                    --(cheap rollup)-->  denials_90d   (SAME tiles)
                                                    --(cheap rollup)-->  txn_count_7d
                                                    --(cheap rollup)-->  amount_sum_30d

Production mapping: this is a daily Spark GROUP BY over one date partition,
appended to an Iceberg tile table. The roll-up is a windowed sum over tiles.
"""
from __future__ import annotations

import re
import pandas as pd
from .spec import FeatureSpec

# instrumentation: prove the source is scanned only once
SOURCE_SCANS = 0


def reset_scan_counter():
    global SOURCE_SCANS
    SOURCE_SCANS = 0


def _safe(s: str) -> str:
    return re.sub(r"\W+", "_", s.strip()).strip("_")


def measure_cols_for(spec: FeatureSpec) -> list[tuple[str, str, str | None, str | None]]:
    """
    Map a feature spec to the daily tile column(s) it needs.
    Returns list of (col_name, kind, field, filter_expr).
    avg needs two base columns (sum + count); everything else needs one.
    """
    filt = spec.filter_expr
    fkey = "all" if not filt else _safe(filt)
    a = spec.aggregation
    if a == "count":
        return [(f"count__row__{fkey}", "count", None, filt)]
    if a == "sum":
        return [(f"sum__{spec.agg_field}__{fkey}", "sum", spec.agg_field, filt)]
    if a == "avg":
        return [(f"sum__{spec.agg_field}__{fkey}", "sum", spec.agg_field, filt),
                (f"count__row__{fkey}", "count", None, filt)]
    if a == "min":
        return [(f"min__{spec.agg_field}__{fkey}", "min", spec.agg_field, filt)]
    if a == "max":
        return [(f"max__{spec.agg_field}__{fkey}", "max", spec.agg_field, filt)]
    if a == "count_distinct":
        return [(f"set__{spec.agg_field}__{fkey}", "set", spec.agg_field, filt)]
    raise ValueError(a)


def required_measures(specs: list[FeatureSpec]) -> list[tuple[str, str, str | None, str | None]]:
    seen = {}
    for s in specs:
        for col in measure_cols_for(s):
            seen[col[0]] = col
    return list(seen.values())


def build_tiles(source_df: pd.DataFrame, specs: list[FeatureSpec],
                entity: str = "account_id", ts_col: str = "txn_ts") -> pd.DataFrame:
    """
    ONE pass over the source: produce daily per-entity tiles holding every base
    measure the given specs need. This is the only time raw records are scanned.
    """
    global SOURCE_SCANS
    SOURCE_SCANS += 1   # <-- the single source scan

    df = source_df.copy()
    df[ts_col] = pd.to_datetime(df[ts_col])
    df["date"] = df[ts_col].dt.floor("D")

    measures = required_measures(specs)
    grp = df.groupby([entity, "date"])
    out = pd.DataFrame(index=grp.size().index)

    for col, kind, field, filt in measures:
        sub = df.query(filt) if filt else df
        g = sub.groupby([entity, "date"])
        if kind == "count":
            series = g.size()
        elif kind == "sum":
            series = g[field].sum()
        elif kind == "min":
            series = g[field].min()
        elif kind == "max":
            series = g[field].max()
        elif kind == "set":
            series = g[field].apply(lambda s: "|".join(map(str, sorted(set(s)))))
        else:
            raise ValueError(kind)
        out[col] = series

    out = out.reset_index()
    # numeric measures: missing day = 0; set measures: empty string
    for col, kind, *_ in measures:
        if kind == "set":
            out[col] = out[col].fillna("")
        else:
            out[col] = out[col].fillna(0)
    return out.sort_values([entity, "date"]).reset_index(drop=True)


def build_tiles_incremental(existing_tiles: pd.DataFrame, new_day_df: pd.DataFrame,
                            specs: list[FeatureSpec], entity: str = "account_id",
                            ts_col: str = "txn_ts") -> pd.DataFrame:
    """
    Steady state: compute tiles for ONLY the new day's records and append.
    Yesterday's tiles are immutable — never recomputed. Cost is bounded by one
    day of data, not all history.
    """
    new_tiles = build_tiles(new_day_df, specs, entity, ts_col)
    combined = pd.concat([existing_tiles, new_tiles], ignore_index=True)
    return combined.drop_duplicates([entity, "date"], keep="last").sort_values(
        [entity, "date"]).reset_index(drop=True)
