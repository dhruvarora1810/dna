"""
FeatureSpec — the declarative contract for a velocity feature.

BOTH the analyst UI form and the engineer notebook produce one of these.
The generic engine consumes it. Nobody writes Spark/pandas code per feature.

A velocity feature is always the same shape:
    aggregate <agg_field> using <aggregation>
    over <entity>'s rows in the trailing <window_days>
    optionally filtered by <filter_expr>
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Optional
import yaml

VALID_AGGREGATIONS = {"count", "sum", "avg", "min", "max", "count_distinct"}


@dataclass
class FeatureSpec:
    name: str                      # 'denials_30d'
    entity: str                    # 'account_id'
    timestamp_col: str             # 'txn_ts'
    source: str                    # 'authorizations'
    aggregation: str               # one of VALID_AGGREGATIONS
    window_days: int               # 30
    agg_field: Optional[str] = None        # field to sum/avg/distinct (None for plain count)
    filter_expr: Optional[str] = None      # pandas query() expr, e.g. "decision == 'DENY'"
    data_type: str = "double"
    description: str = ""
    owner: str = "unknown"

    # ---------- validation ----------
    def validate(self) -> "FeatureSpec":
        errors = []
        if not self.name or " " in self.name:
            errors.append("name must be non-empty with no spaces")
        if self.aggregation not in VALID_AGGREGATIONS:
            errors.append(f"aggregation must be one of {sorted(VALID_AGGREGATIONS)}")
        if self.aggregation in {"sum", "avg", "min", "max", "count_distinct"} and not self.agg_field:
            errors.append(f"aggregation '{self.aggregation}' requires agg_field")
        if self.window_days <= 0:
            errors.append("window_days must be positive")
        if errors:
            raise ValueError(f"Invalid spec '{self.name}': " + "; ".join(errors))
        return self

    # ---------- serialization ----------
    def to_yaml(self) -> str:
        return yaml.safe_dump(asdict(self), sort_keys=False)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_yaml(cls, text: str) -> "FeatureSpec":
        return cls(**yaml.safe_load(text)).validate()

    @classmethod
    def from_dict(cls, d: dict) -> "FeatureSpec":
        return cls(**d).validate()
