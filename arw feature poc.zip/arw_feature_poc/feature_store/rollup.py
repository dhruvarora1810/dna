"""
Roll-up engine — turns daily tiles into window features. Reads ONLY the tile
table, never the raw source. This is what makes adding a feature or changing
30->90 days cheap: it's a windowed roll-up over tiny daily tiles.

Point-in-time definition at daily grain: the value as of a given day uses the
COMPLETE prior days in the window (rolling closed='left'), so the current day's
in-progress activity never leaks. Standard for 7/30/90-day velocity features.
"""
from __future__ import annotations

import pandas as pd
from .spec import FeatureSpec
from .tiles import measure_cols_for


def rollup(spec: FeatureSpec, tiles: pd.DataFrame,
           entity: str = "account_id") -> pd.DataFrame:
    """
    Compute `spec` (a window feature) from the daily `tiles`.
    Returns daily series: [entity, date, <spec.name>].
    No access to raw records.
    """
    spec.validate()
    cols = measure_cols_for(spec)
    window = f"{spec.window_days}D"
    frames = []

    for ent, g in tiles.sort_values("date").groupby(entity):
        g = g.set_index("date")
        # reindex to a continuous daily calendar so the time-window is correct
        full = pd.date_range(g.index.min(), g.index.max(), freq="D")
        g = g.reindex(full)

        if spec.aggregation == "count":
            col = cols[0][0]
            val = g[col].fillna(0).rolling(window, closed="left").sum()
        elif spec.aggregation == "sum":
            col = cols[0][0]
            val = g[col].fillna(0).rolling(window, closed="left").sum()
        elif spec.aggregation == "avg":
            sum_col, cnt_col = cols[0][0], cols[1][0]
            s = g[sum_col].fillna(0).rolling(window, closed="left").sum()
            c = g[cnt_col].fillna(0).rolling(window, closed="left").sum()
            val = (s / c).fillna(0)
        elif spec.aggregation == "min":
            col = cols[0][0]
            val = g[col].rolling(window, closed="left").min()
        elif spec.aggregation == "max":
            col = cols[0][0]
            val = g[col].rolling(window, closed="left").max()
        elif spec.aggregation == "count_distinct":
            # union the daily sets over the window, then count.
            # (production: mergeable HyperLogLog sketches per day; here: exact set union)
            col = cols[0][0]
            sets = g[col].fillna("")

            def _win_distinct(idx_pos):
                pass  # placeholder; handled below

            n = spec.window_days
            vals = []
            arr = sets.tolist()
            for i in range(len(arr)):
                lo = max(0, i - n)
                window_slice = arr[lo:i]  # strictly prior days
                u = set()
                for cell in window_slice:
                    if cell:
                        u.update(cell.split("|"))
                vals.append(len(u))
            val = pd.Series(vals, index=g.index)
        else:
            raise ValueError(spec.aggregation)

        res = val.reset_index()
        res.columns = ["date", spec.name]
        res[entity] = ent
        frames.append(res)

    out = pd.concat(frames, ignore_index=True)
    out[spec.name] = out[spec.name].fillna(0)
    if spec.data_type == "int":
        out[spec.name] = out[spec.name].astype(int)
    return out[[entity, "date", spec.name]].sort_values([entity, "date"]).reset_index(drop=True)
