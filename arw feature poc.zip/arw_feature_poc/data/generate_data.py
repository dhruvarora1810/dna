"""
Generate a synthetic credit-card authorization table for the feature-store POC.

Mirrors the shape of a real bank auth feed (think SASFM / FAME / IBS-Auth):
one row per authorization attempt, APPROVE or DENY, with merchant + amount.

Run:  python data/generate_data.py
Output: data/authorizations.csv
"""
import numpy as np
import pandas as pd
from pathlib import Path

RNG = np.random.default_rng(42)

N_ACCOUNTS = 300
DAYS = 120                       # ~4 months of history
AVG_TXN_PER_ACCT_PER_DAY = 0.8   # sparse, realistic
MCCS = [5411, 5812, 5912, 5541, 4900, 5732, 7995, 6011, 5999, 4829]  # grocery, dining, pharmacy, gas, utils, electronics, gambling, ATM, misc, money-transfer
HIGH_RISK_MCCS = {7995, 4829, 6011}  # gambling, money-transfer, ATM -> higher denial rate


def generate() -> pd.DataFrame:
    start = pd.Timestamp("2026-01-01")
    rows = []
    txn_id = 0
    for acct in range(1, N_ACCOUNTS + 1):
        account_id = f"ACCT{acct:05d}"
        # each account has a baseline fraud-proneness
        base_deny = RNG.uniform(0.02, 0.10)
        # a small cohort are "risky" accounts with bursts of denials
        risky = RNG.random() < 0.08
        for day in range(DAYS):
            n_txn = RNG.poisson(AVG_TXN_PER_ACCT_PER_DAY)
            for _ in range(n_txn):
                txn_id += 1
                ts = start + pd.Timedelta(days=day) + pd.Timedelta(
                    seconds=int(RNG.integers(0, 86400))
                )
                mcc = int(RNG.choice(MCCS))
                amount = float(np.round(RNG.gamma(2.0, 40.0), 2))  # skewed, mostly small
                # denial probability
                p = base_deny
                if mcc in HIGH_RISK_MCCS:
                    p += 0.10
                if amount > 250:
                    p += 0.05
                if risky and day % 30 < 5:   # risky accounts have denial bursts
                    p += 0.35
                decision = "DENY" if RNG.random() < min(p, 0.95) else "APPROVE"
                rows.append((txn_id, account_id, ts, mcc, amount, decision))

    df = pd.DataFrame(
        rows,
        columns=["txn_id", "account_id", "txn_ts", "mcc", "amount", "decision"],
    ).sort_values("txn_ts").reset_index(drop=True)
    return df


if __name__ == "__main__":
    out = Path(__file__).parent / "authorizations.csv"
    df = generate()
    df.to_csv(out, index=False)
    print(f"Wrote {len(df):,} authorizations for {df.account_id.nunique()} accounts -> {out}")
    print(df.head(8).to_string(index=False))
    print(f"\nOverall denial rate: {(df.decision=='DENY').mean():.1%}")
