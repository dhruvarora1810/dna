"""
Feature-Builder UI  —  the ANALYST's door.

A no-code form that produces a declarative FeatureSpec, previews it on the
sample data, and submits it for approval. A second tab is the SUPERVISOR's
approval queue. A third shows the live catalog + audit trail.

Run:  streamlit run app/streamlit_app.py
"""
import sys
from pathlib import Path

import pandas as pd
import streamlit as st

sys.path.insert(0, str(Path(__file__).parent.parent))
from feature_store import FeatureSpec, engine, registry, store  # noqa: E402

st.set_page_config(page_title="ARW Feature Builder", layout="wide")

# ---- bootstrap ----
ROOT = Path(__file__).parent.parent
registry.init_db()


@st.cache_data
def load_source():
    return pd.read_csv(ROOT / "data" / "authorizations.csv")


auth = load_source()
NUMERIC_FIELDS = ["amount"]
CATEGORICAL_FIELDS = ["mcc", "decision"]
ALL_FIELDS = ["amount", "mcc", "decision"]

st.title("🛡️  ARW Feature Builder")
st.caption("Define governed velocity features for fraud rules — no code. "
           f"Sample source: {len(auth):,} credit-card authorizations, {auth.account_id.nunique()} accounts.")

tab_build, tab_approve, tab_catalog = st.tabs(
    ["➕ Build a feature", "✅ Approval queue", "📚 Catalog & audit"]
)

# ============================================================ BUILD
with tab_build:
    st.subheader("Build a velocity feature")
    c1, c2, c3 = st.columns(3)

    with c1:
        agg = st.selectbox("Aggregation", ["count", "sum", "avg", "min", "max", "count_distinct"])
        needs_field = agg != "count"
        agg_field = None
        if needs_field:
            field_choices = NUMERIC_FIELDS if agg in {"sum", "avg", "min", "max"} else ALL_FIELDS
            agg_field = st.selectbox("Field to aggregate", field_choices)

    with c2:
        window_days = st.number_input("Window (days)", min_value=1, max_value=365, value=30)
        entity = st.selectbox("Entity", ["account_id"])

    with c3:
        use_filter = st.checkbox("Add a filter")
        filter_expr = None
        if use_filter:
            fcol = st.selectbox("Filter field", CATEGORICAL_FIELDS)
            fval = st.selectbox("Equals", sorted(auth[fcol].astype(str).unique().tolist()))
            # quote string values
            filter_expr = f"{fcol} == '{fval}'" if auth[fcol].dtype == object else f"{fcol} == {fval}"

    # auto-suggest a name
    if use_filter and filter_expr:
        default_name = f"{str(fval).lower()}_{agg}_{window_days}d"
    elif agg == "count":
        default_name = f"txn_count_{window_days}d"
    else:
        default_name = f"{agg_field}_{agg}_{window_days}d"
    name = st.text_input("Feature name", value=default_name.replace("__", "_"))
    description = st.text_input("Description", value="")
    owner = st.text_input("Owner", value="da60046")

    # build the spec live
    try:
        spec = FeatureSpec(
            name=name, entity=entity, timestamp_col="txn_ts", source="authorizations",
            aggregation=agg, window_days=int(window_days), agg_field=agg_field,
            filter_expr=filter_expr,
            data_type="int" if agg in {"count", "count_distinct"} else "double",
            description=description, owner=owner,
        ).validate()
        spec_ok = True
    except Exception as e:  # noqa: BLE001
        st.error(str(e))
        spec_ok = False

    if spec_ok:
        st.markdown("**Generated spec** (this is what gets submitted — not code):")
        st.code(spec.to_yaml(), language="yaml")

        cprev, csub = st.columns(2)
        with cprev:
            if st.button("👁 Preview on sample data", use_container_width=True):
                with st.spinner("Computing point-in-time values…"):
                    feats = engine.materialize(spec, auth)
                st.write(f"Rows produced: **{len(feats):,}**")
                st.dataframe(feats[spec.name].describe().to_frame().T, use_container_width=True)
                st.dataframe(feats.head(15), use_container_width=True)
                st.bar_chart(feats[spec.name].value_counts().sort_index().head(20))

        with csub:
            if st.button("📤 Submit for approval", type="primary", use_container_width=True):
                registry.submit_feature(spec, actor=owner)
                st.success(f"Submitted '{spec.name}' → status: in_review. "
                           f"See the Approval queue tab.")

# ============================================================ APPROVE
with tab_approve:
    st.subheader("Approval queue  (supervisor)")
    pending = registry.list_features(status="in_review")
    if not pending:
        st.info("Nothing waiting for approval.")
    for f in pending:
        with st.container(border=True):
            st.markdown(f"**{f['name']}**  · owner `{f['owner']}` · v{f['version']}")
            spec = registry.get_spec(f["name"])
            st.code(spec.to_yaml(), language="yaml")
            colA, colB = st.columns([3, 1])
            note = colA.text_input("Review note", key=f"note_{f['name']}")
            if colB.button("✅ Approve", key=f"appr_{f['name']}", type="primary"):
                registry.approve_feature(f["name"], approver="supervisor", note=note)
                # materialize on approval (the auto-trigger)
                try:
                    p = store.materialize_to_store(f["name"], auth)
                    st.success(f"Approved & materialized → {p.name}")
                except Exception as e:  # noqa: BLE001
                    st.warning(f"Approved, but materialize failed: {e}")
                st.rerun()

# ============================================================ CATALOG
with tab_catalog:
    st.subheader("Feature catalog")
    feats = registry.list_features()
    if feats:
        df = pd.DataFrame(feats)[["name", "entity", "status", "version", "owner", "data_type", "updated_at"]]
        st.dataframe(df, use_container_width=True)

        st.subheader("Materialized values")
        prod = [f["name"] for f in feats if f["status"] == "production"]
        if prod:
            pick = st.selectbox("Feature", prod)
            path = ROOT / "feature_tables" / f"{pick}.csv"
            if path.exists():
                st.dataframe(pd.read_csv(path).head(50), use_container_width=True)
            else:
                st.info("Not materialized yet — approve it in the queue tab.")
    else:
        st.info("No features yet — build one in the first tab.")

    st.subheader("Audit trail")
    trail = registry.audit_trail()
    if trail:
        st.dataframe(pd.DataFrame(trail)[["created_at", "feature_name", "action", "actor", "detail"]],
                     use_container_width=True)
